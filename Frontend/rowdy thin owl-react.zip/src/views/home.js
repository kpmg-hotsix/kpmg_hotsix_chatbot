import React from 'react'

import { Helmet } from 'react-helmet'

import './home.css'

const Home = (props) => {
  return (
    <div className="home-container">
      <Helmet>
        <title>Rowdy Thin Owl</title>
        <meta property="og:title" content="Rowdy Thin Owl" />
      </Helmet>
      <div className="home-patient-dashboardlight-theme-login-page">
        <img
          alt="KakaoTalkPhoto2022120721342811140"
          src="/playground_assets/kakaotalkphoto2022120721342811140-ts3c-200w.png"
          className="home-kakao-talk-photo202212072134281"
        />
      </div>
      <div className="home-patient-dashboard-registration-page">
        <img
          alt="Shape1135"
          src="/playground_assets/shape1135-ygvg.svg"
          className="home-shape"
        />
        <img
          alt="KakaoTalkPhoto2022120721342811135"
          src="/playground_assets/kakaotalkphoto2022120721342811135-o8e-200w.png"
          className="home-kakao-talk-photo2022120721342811"
        />
        <img
          alt="Rectangle1135"
          src="/playground_assets/rectangle1135-zg2.svg"
          className="home-rectangle"
        />
        <img
          alt="Rectangle1135"
          src="/playground_assets/rectangle1135-zbt.svg"
          className="home-rectangle001"
        />
        <img
          alt="Rectangle1135"
          src="/playground_assets/rectangle1135-9yrg.svg"
          className="home-rectangle002"
        />
        <img
          alt="Rectangle1135"
          src="/playground_assets/rectangle1135-keen.svg"
          className="home-rectangle003"
        />
        <img
          alt="Shape1135"
          src="/playground_assets/shape1135-hhqj.svg"
          className="home-shape001"
        />
        <img
          alt="Rectangle1136"
          src="/playground_assets/rectangle1136-nvro.svg"
          className="home-rectangle004"
        />
        <img
          alt="Circle1136"
          src="/playground_assets/circle1136-qxc-200h.png"
          className="home-circle"
        />
        <img
          alt="Shape1136"
          src="/playground_assets/shape1136-hec.svg"
          className="home-shape002"
        />
        <img
          alt="Shape1136"
          src="/playground_assets/shape1136-ntso.svg"
          className="home-shape003"
        />
        <span className="home-text">
          <span>CREATE ACCOUNT</span>
        </span>
        <span className="home-text002">
          <span>Name</span>
        </span>
        <span className="home-text004">
          <span>Email</span>
        </span>
        <span className="home-text006">
          <span>Password</span>
        </span>
        <span className="home-text008">
          <span>Ola boluwatife</span>
        </span>
        <span className="home-text010">
          <span>Olaboluwatofezzy@ymail.com</span>
        </span>
        <span className="home-text012">
          <span>XXXXXXXXXXXXXX</span>
        </span>
        <span className="home-text014">
          <span>I accept the</span>
        </span>
        <span className="home-text016">
          <span>Terms &amp; Conditions</span>
        </span>
        <span className="home-text018">
          <span>Already have an account?</span>
        </span>
        <span className="home-text020">
          <span>Login</span>
        </span>
      </div>
      <div className="home-patient-dashboardlight-theme-login-page1">
        <div className="home-patient-dashboardlight-theme-login-page2">
          <img
            alt="Shape1138"
            src="/playground_assets/shape1138-3mtl.svg"
            className="home-shape004"
          />
          <div className="home-svg2">
            <img
              alt="Circle1138"
              src="/playground_assets/circle1138-rx8u-200h.png"
              className="home-circle01"
            />
            <img
              alt="Shape1138"
              src="/playground_assets/shape1138-4hj.svg"
              className="home-shape005"
            />
            <img
              alt="Shape1138"
              src="/playground_assets/shape1138-8w3.svg"
              className="home-shape006"
            />
          </div>
          <img
            alt="KakaoTalkPhoto2022120721342811138"
            src="/playground_assets/kakaotalkphoto2022120721342811138-calt-200w.png"
            className="home-kakao-talk-photo2022120721342812"
          />
          <span className="home-text022">
            <span>LOGIN</span>
          </span>
          <span className="home-text024">
            <span>Email</span>
          </span>
          <span className="home-text026">
            <span>Password</span>
          </span>
          <img
            alt="Rectangle1139"
            src="/playground_assets/rectangle1139-hytc.svg"
            className="home-rectangle005"
          />
          <span className="home-text028">
            <span>Olaboluwatofezzy@ymail.com</span>
          </span>
          <img
            alt="Rectangle1139"
            src="/playground_assets/rectangle1139-0nsj.svg"
            className="home-rectangle006"
          />
          <img
            alt="Rectangle1139"
            src="/playground_assets/rectangle1139-b3mi.svg"
            className="home-rectangle007"
          />
          <img
            alt="Rectangle1139"
            src="/playground_assets/rectangle1139-5oci.svg"
            className="home-rectangle008"
          />
          <span className="home-text030">
            <span>XXXXXXXXXXXXXX</span>
          </span>
          <span className="home-text032">
            <span>Remember Me</span>
          </span>
          <span className="home-text034">
            <span>LOGIN</span>
          </span>
          <span className="home-text036">
            <span>Forgot Password?</span>
          </span>
          <span className="home-text038">
            <span>Don&apos;t have an account?</span>
          </span>
          <span className="home-text040">
            <span>Create an account</span>
          </span>
        </div>
      </div>
      <div className="home-desktop5">
        <img
          alt="Rectangle1109"
          src="/playground_assets/rectangle1109-4uvd.svg"
          className="home-rectangle009"
        />
        <img
          alt="Rectangle1109"
          src="/playground_assets/rectangle1109-pexc.svg"
          className="home-rectangle010"
        />
        <img
          alt="Rectangle1109"
          src="/playground_assets/rectangle1109-2icv.svg"
          className="home-rectangle011"
        />
        <span className="home-text042">
          <span>
            <span>
              회사 C는 자연어처리 기술을 활용해 금융권의
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
            <br></br>
            <span>비정형 데이터 자산화 서비스를 제공하는 기업입니다.</span>
          </span>
        </span>
        <img
          alt="Rectangle1109"
          src="/playground_assets/rectangle1109-xp8j.svg"
          className="home-rectangle012"
        />
        <img
          alt="Rectangle1109"
          src="/playground_assets/rectangle1109-0rkp.svg"
          className="home-rectangle013"
        />
        <img
          alt="Circle1109"
          src="/playground_assets/circle1109-ba7t-200h.png"
          className="home-circle02"
        />
        <div className="home-group">
          <img
            alt="Shape1110"
            src="/playground_assets/shape1110-fld.svg"
            className="home-shape007"
          />
          <div className="home-maskgroup">
            <div className="home-group01">
              <img
                alt="Shape1110"
                src="/playground_assets/shape1110-fiui.svg"
                className="home-shape008"
              />
              <img
                alt="Shape1111"
                src="/playground_assets/shape1111-vao.svg"
                className="home-shape009"
              />
              <img
                alt="Shape1111"
                src="/playground_assets/shape1111-4l3o.svg"
                className="home-shape010"
              />
            </div>
          </div>
        </div>
        <img
          alt="Shape1111"
          src="/playground_assets/shape1111-6g3d.svg"
          className="home-shape011"
        />
        <div className="home-maskgroup01"></div>
        <img
          alt="Shape1111"
          src="/playground_assets/shape1111-qmze.svg"
          className="home-shape012"
        />
        <div className="home-maskgroup02"></div>
        <img
          alt="Circle1111"
          src="/playground_assets/circle1111-djmm-200h.png"
          className="home-circle03"
        />
        <img
          alt="Circle1111"
          src="/playground_assets/circle1111-nzc-200w.png"
          className="home-circle04"
        />
        <img
          alt="Circle1112"
          src="/playground_assets/circle1112-j4cd-200w.png"
          className="home-circle05"
        />
        <img
          alt="Circle1112"
          src="/playground_assets/circle1112-5hcw-200w.png"
          className="home-circle06"
        />
        <span className="home-text047">
          <span>191.8k</span>
        </span>
        <img
          alt="Rectangle1112"
          src="/playground_assets/rectangle1112-akjb.svg"
          className="home-rectangle014"
        />
        <span className="home-text049">
          <span>회사 B</span>
        </span>
        <span className="home-text051">
          <span>회사 C</span>
        </span>
        <img
          alt="Rectangle1112"
          src="/playground_assets/rectangle1112-abjf.svg"
          className="home-rectangle015"
        />
        <img
          alt="Circle1112"
          src="/playground_assets/circle1112-10na-200h.png"
          className="home-circle07"
        />
        <div className="home-group02">
          <img
            alt="Shape1112"
            src="/playground_assets/shape1112-mnx.svg"
            className="home-shape013"
          />
          <div className="home-maskgroup03">
            <div className="home-group03">
              <img
                alt="Shape1113"
                src="/playground_assets/shape1113-ther.svg"
                className="home-shape014"
              />
              <img
                alt="Shape1113"
                src="/playground_assets/shape1113-irbt.svg"
                className="home-shape015"
              />
              <img
                alt="Shape1113"
                src="/playground_assets/shape1113-7t3.svg"
                className="home-shape016"
              />
            </div>
          </div>
        </div>
        <img
          alt="Shape1114"
          src="/playground_assets/shape1114-lbi8.svg"
          className="home-shape017"
        />
        <div className="home-maskgroup04"></div>
        <img
          alt="Shape1114"
          src="/playground_assets/shape1114-nu.svg"
          className="home-shape018"
        />
        <div className="home-maskgroup05"></div>
        <img
          alt="Circle1114"
          src="/playground_assets/circle1114-gxgdr-200h.png"
          className="home-circle08"
        />
        <img
          alt="Circle1114"
          src="/playground_assets/circle1114-skkd-200w.png"
          className="home-circle09"
        />
        <img
          alt="Circle1114"
          src="/playground_assets/circle1114-9a02-200w.png"
          className="home-circle10"
        />
        <img
          alt="Circle1114"
          src="/playground_assets/circle1114-ub5b-200w.png"
          className="home-circle11"
        />
        <span className="home-text053">
          <span>203.5k</span>
        </span>
        <img
          alt="Rectangle1115"
          src="/playground_assets/rectangle1115-0w5.svg"
          className="home-rectangle016"
        />
        <span className="home-text055">
          <span>회사 A</span>
        </span>
        <span className="home-text057">O</span>
        <span className="home-text058">T</span>
        <span className="home-text059">S</span>
        <span className="home-text060">I</span>
        <span className="home-text061">H</span>
        <img
          alt="Shape1115"
          src="/playground_assets/shape1115-me1.svg"
          className="home-shape019"
        />
        <img
          alt="Line1116"
          src="/playground_assets/line1116-unei.svg"
          className="home-line"
        />
        <img
          alt="Shape1116"
          src="/playground_assets/shape1116-mhjo.svg"
          className="home-shape020"
        />
        <img
          alt="Rectangle1116"
          src="/playground_assets/rectangle1116-pyd-200h.png"
          className="home-rectangle017"
        />
        <span className="home-text062">
          <span>Overview</span>
        </span>
        <img
          alt="Rectangle1116"
          src="/playground_assets/rectangle1116-bok.svg"
          className="home-rectangle018"
        />
        <img
          alt="Circle1116"
          src="/playground_assets/circle1116-gd7-200h.png"
          className="home-circle12"
        />
        <div className="home-group04">
          <img
            alt="Shape1116"
            src="/playground_assets/shape1116-dj9.svg"
            className="home-shape021"
          />
          <div className="home-maskgroup06">
            <div className="home-group05">
              <img
                alt="Shape1117"
                src="/playground_assets/shape1117-ux4.svg"
                className="home-shape022"
              />
              <img
                alt="Shape1117"
                src="/playground_assets/shape1117-1n66.svg"
                className="home-shape023"
              />
              <img
                alt="Shape1117"
                src="/playground_assets/shape1117-xm3l.svg"
                className="home-shape024"
              />
            </div>
          </div>
        </div>
        <img
          alt="Shape1118"
          src="/playground_assets/shape1118-l1jr.svg"
          className="home-shape025"
        />
        <div className="home-maskgroup07"></div>
        <img
          alt="Shape1118"
          src="/playground_assets/shape1118-taft.svg"
          className="home-shape026"
        />
        <div className="home-maskgroup08"></div>
        <img
          alt="Circle1118"
          src="/playground_assets/circle1118-4rg8-200h.png"
          className="home-circle13"
        />
        <img
          alt="Circle1118"
          src="/playground_assets/circle1118-o796-200w.png"
          className="home-circle14"
        />
        <img
          alt="Circle1118"
          src="/playground_assets/circle1118-ro4-200w.png"
          className="home-circle15"
        />
        <img
          alt="Circle1118"
          src="/playground_assets/circle1118-x9lb-200w.png"
          className="home-circle16"
        />
        <span className="home-text064">
          <span>187.2k</span>
        </span>
        <div className="home-patient-dashboard-chats-light-theme">
          <img
            alt="Rectangle1119"
            src="/playground_assets/rectangle1119-02q.svg"
            className="home-rectangle019"
          />
          <div className="home-group06">
            <img
              alt="Rectangle1119"
              src="/playground_assets/rectangle1119-q3rm.svg"
              className="home-rectangle020"
            />
          </div>
          <img
            alt="Shape1119"
            src="/playground_assets/shape1119-feks.svg"
            className="home-shape027"
          />
          <img
            alt="Shape1119"
            src="/playground_assets/shape1119-ty3.svg"
            className="home-shape028"
          />
          <img
            alt="Shape1119"
            src="/playground_assets/shape1119-in6e.svg"
            className="home-shape029"
          />
          <img
            alt="Shape1119"
            src="/playground_assets/shape1119-rf6p.svg"
            className="home-shape030"
          />
          <img
            alt="Shape1119"
            src="/playground_assets/shape1119-uqcg.svg"
            className="home-shape031"
          />
          <img
            alt="Shape1120"
            src="/playground_assets/shape1120-k9h5j.svg"
            className="home-shape032"
          />
          <img
            alt="Shape1120"
            src="/playground_assets/shape1120-gz9l.svg"
            className="home-shape033"
          />
          <img
            alt="Shape1120"
            src="/playground_assets/shape1120-h799.svg"
            className="home-shape034"
          />
          <img
            alt="Shape1120"
            src="/playground_assets/shape1120-9ktp.svg"
            className="home-shape035"
          />
          <img
            alt="Shape1120"
            src="/playground_assets/shape1120-nmor.svg"
            className="home-shape036"
          />
          <img
            alt="Shape1120"
            src="/playground_assets/shape1120-m1h.svg"
            className="home-shape037"
          />
          <img
            alt="Shape1120"
            src="/playground_assets/shape1120-8gu.svg"
            className="home-shape038"
          />
          <img
            alt="Line1120"
            src="/playground_assets/line1120-sgy8.svg"
            className="home-line01"
          />
          <img
            alt="Circle1120"
            src="/playground_assets/circle1120-f23j-200h.png"
            className="home-circle17"
          />
          <img
            alt="Circle1120"
            src="/playground_assets/circle1120-n2tm-200h.png"
            className="home-circle18"
          />
          <div className="home-group4">
            <img
              alt="Shape1121"
              src="/playground_assets/shape1121-jd7.svg"
              className="home-shape039"
            />
            <img
              alt="Shape1121"
              src="/playground_assets/shape1121-ddl6.svg"
              className="home-shape040"
            />
          </div>
          <img
            alt="Circle1121"
            src="/playground_assets/circle1121-pv81-200h.png"
            className="home-circle19"
          />
          <div className="home-notification-bell">
            <img
              alt="Shape1121"
              src="/playground_assets/shape1121-u3w.svg"
              className="home-shape041"
            />
            <img
              alt="Shape1121"
              src="/playground_assets/shape1121-cf68.svg"
              className="home-shape042"
            />
            <img
              alt="Shape1121"
              src="/playground_assets/shape1121-ngu7.svg"
              className="home-shape043"
            />
          </div>
          <img
            alt="Line1122"
            src="/playground_assets/line1122-n9tj.svg"
            className="home-line02"
          />
          <img
            alt="Line1122"
            src="/playground_assets/line1122-fx6f.svg"
            className="home-line03"
          />
          <img
            alt="Rectangle1122"
            src="/playground_assets/rectangle1122-1ma.svg"
            className="home-rectangle021"
          />
          <img
            alt="Shape1122"
            src="/playground_assets/shape1122-76f.svg"
            className="home-shape044"
          />
          <img
            alt="Shape1122"
            src="/playground_assets/shape1122-5cqh.svg"
            className="home-shape045"
          />
          <img
            alt="Shape1122"
            src="/playground_assets/shape1122-4i3.svg"
            className="home-shape046"
          />
          <img
            alt="Shape1122"
            src="/playground_assets/shape1122-cqgd.svg"
            className="home-shape047"
          />
          <div className="home-group2">
            <img
              alt="Shape1123"
              src="/playground_assets/shape1123-rq3p.svg"
              className="home-shape048"
            />
            <img
              alt="Shape1123"
              src="/playground_assets/shape1123-63b4.svg"
              className="home-shape049"
            />
            <img
              alt="Shape1123"
              src="/playground_assets/shape1123-914i.svg"
              className="home-shape050"
            />
            <img
              alt="Shape1123"
              src="/playground_assets/shape1123-hlt.svg"
              className="home-shape051"
            />
            <img
              alt="Shape1123"
              src="/playground_assets/shape1123-exom.svg"
              className="home-shape052"
            />
          </div>
          <img
            alt="Shape1123"
            src="/playground_assets/shape1123-vss.svg"
            className="home-shape053"
          />
          <img
            alt="Shape1124"
            src="/playground_assets/shape1124-bn0o.svg"
            className="home-shape054"
          />
          <span className="home-text066">
            <span>Chats</span>
          </span>
          <span className="home-text068">
            <span>Apply Dark Theme</span>
          </span>
          <span className="home-text070">
            <span>Ola Boluwatife</span>
          </span>
          <span className="home-text072">
            <span>Samsung electronics</span>
          </span>
          <span className="home-text074">
            <span>Search pathology results</span>
          </span>
          <span className="home-text076">
            <span>Chats</span>
          </span>
          <span className="home-text078">
            <span>Settings</span>
          </span>
          <span className="home-text080">
            <span>+234 92 928 2891 +234 60 621 2098</span>
          </span>
          <span className="home-text082">
            <span>Logouts</span>
          </span>
          <span className="home-text084">
            <span>Emergency Hotlines:</span>
          </span>
          <span className="home-text086">
            <span>ACCOUNT</span>
          </span>
          <img
            alt="Shape1125"
            src="/playground_assets/shape1125-ks74.svg"
            className="home-shape055"
          />
          <div className="home-group7">
            <img
              alt="Shape1125"
              src="/playground_assets/shape1125-2wzr.svg"
              className="home-shape056"
            />
            <img
              alt="Shape1125"
              src="/playground_assets/shape1125-e36g.svg"
              className="home-shape057"
            />
          </div>
          <img
            alt="Shape1125"
            src="/playground_assets/shape1125-fg92.svg"
            className="home-shape058"
          />
          <img
            alt="Line1126"
            src="/playground_assets/line1126-9wy9.svg"
            className="home-line04"
          />
          <img
            alt="Line1126"
            src="/playground_assets/line1126-scld.svg"
            className="home-line05"
          />
          <img
            alt="Line1126"
            src="/playground_assets/line1126-3g88.svg"
            className="home-line06"
          />
          <img
            alt="Circle1126"
            src="/playground_assets/circle1126-lcpn-200h.png"
            className="home-circle20"
          />
          <img
            alt="Circle1126"
            src="/playground_assets/circle1126-i60l-200h.png"
            className="home-circle21"
          />
          <img
            alt="Circle1126"
            src="/playground_assets/circle1126-bgaa-200h.png"
            className="home-circle22"
          />
          <img
            alt="Shape1126"
            src="/playground_assets/shape1126-q3v7.svg"
            className="home-shape059"
          />
          <img
            alt="Shape1126"
            src="/playground_assets/shape1126-1b62.svg"
            className="home-shape060"
          />
          <img
            alt="Shape1126"
            src="/playground_assets/shape1126-ipkq.svg"
            className="home-shape061"
          />
          <img
            alt="Shape1126"
            src="/playground_assets/shape1126-cvxc.svg"
            className="home-shape062"
          />
          <img
            alt="Shape1127"
            src="/playground_assets/shape1127-hbsu.svg"
            className="home-shape063"
          />
          <img
            alt="Shape1127"
            src="/playground_assets/shape1127-rwe9.svg"
            className="home-shape064"
          />
          <img
            alt="Shape1127"
            src="/playground_assets/shape1127-vvs.svg"
            className="home-shape065"
          />
          <img
            alt="Shape1127"
            src="/playground_assets/shape1127-q1v.svg"
            className="home-shape066"
          />
          <img
            alt="Shape1127"
            src="/playground_assets/shape1127-vb5m5.svg"
            className="home-shape067"
          />
          <img
            alt="Rectangle1128"
            src="/playground_assets/rectangle1128-xg2.svg"
            className="home-rectangle022"
          />
          <img
            alt="Rectangle1128"
            src="/playground_assets/rectangle1128-i1qd.svg"
            className="home-rectangle023"
          />
          <img
            alt="Rectangle1128"
            src="/playground_assets/rectangle1128-5q9r.svg"
            className="home-rectangle024"
          />
          <div className="home-maskgroup09">
            <div className="home-group07">
              <img
                alt="Rectangle1128"
                src="/playground_assets/rectangle1128-psg-200h.png"
                className="home-rectangle025"
              />
            </div>
          </div>
          <img
            alt="Rectangle1128"
            src="/playground_assets/rectangle1128-lb1.svg"
            className="home-rectangle026"
          />
          <span className="home-text088">
            <span>Dr. Ibrahim Yekeni</span>
          </span>
          <span className="home-text090">
            <span>DOC 28 min ago</span>
          </span>
          <span className="home-text092">
            <span>ME 28 min ago</span>
          </span>
          <span className="home-text094">
            <span>
              <span>
                자연어 처리 관련 기업은 회사 A,
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <br></br>
              <span>회사 B, 회사 C 외 5개 회사가 있습니다.</span>
            </span>
          </span>
          <span className="home-text099">
            <span>
              <span>
                회사 A는 자연어처리 기술을 활용해 금융권의
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <br></br>
              <span>비정형 데이터 자산화 서비스를 제공하는 기업입니다.</span>
            </span>
          </span>
          <span className="home-text104">
            <span>
              <span>
                회사 B는 자연어처리 기술을 활용해 금융권의
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <br></br>
              <span>비정형 데이터 자산화 서비스를 제공하는 기업입니다.</span>
            </span>
          </span>
          <span className="home-text109">
            <span>기술 키워드 : 자연어 처리, 인공 지능, 교육, 아동</span>
          </span>
          <span className="home-text111">
            <span>기술 키워드 : 자연어 처리, 인공 지능, 교육, 아동</span>
          </span>
          <span className="home-text113">
            <span>기술 키워드 : 자연어 처리, 인공 지능, 교육, 아동</span>
          </span>
          <span className="home-text115">
            <span>자연어 처리 관련 기업 찾아줘</span>
          </span>
          <span className="home-text117">
            <span>Start typing here</span>
          </span>
          <span className="home-text119">
            <span>Active 50min ago</span>
          </span>
          <span className="home-text121">1</span>
          <span className="home-text122">2</span>
          <span className="home-text123">1</span>
          <span className="home-text124">
            <span>input text</span>
          </span>
          <span className="home-text126">X</span>
          <img
            alt="KakaoTalkPhoto2022120721342811130"
            src="/playground_assets/kakaotalkphoto2022120721342811130-w6ut-200w.png"
            className="home-kakao-talk-photo2022120721342813"
          />
          <span className="home-text127">H</span>
          <span className="home-text128">O</span>
          <span className="home-text129">T</span>
          <span className="home-text130">S</span>
          <span className="home-text131">I</span>
          <span className="home-text132">H</span>
          <span className="home-text133">X</span>
          <img
            alt="Shape1131"
            src="/playground_assets/shape1131-4zyg.svg"
            className="home-shape068"
          />
          <img
            alt="Shape1131"
            src="/playground_assets/shape1131-id15.svg"
            className="home-shape069"
          />
          <img
            alt="Shape1132"
            src="/playground_assets/shape1132-7b.svg"
            className="home-shape070"
          />
          <img
            alt="Shape1132"
            src="/playground_assets/shape1132-5p0i.svg"
            className="home-shape071"
          />
          <img
            alt="Shape1132"
            src="/playground_assets/shape1132-p6pe.svg"
            className="home-shape072"
          />
          <img
            alt="Shape1133"
            src="/playground_assets/shape1133-p98l.svg"
            className="home-shape073"
          />
          <img
            alt="Shape1133"
            src="/playground_assets/shape1133-mkvd.svg"
            className="home-shape074"
          />
          <img
            alt="Shape1133"
            src="/playground_assets/shape1133-8r18.svg"
            className="home-shape075"
          />
          <img
            alt="Rectangle1134"
            src="/playground_assets/rectangle1134-0tbm.svg"
            className="home-rectangle027"
          />
          <img
            alt="Shape1134"
            src="/playground_assets/shape1134-byur.svg"
            className="home-shape076"
          />
          <span className="home-text134">
            <span>회사 B</span>
          </span>
          <span className="home-text136">
            <span>회사 C</span>
          </span>
        </div>
        <span className="home-text138">
          <span>회사 A</span>
        </span>
      </div>
      <div className="home-desktop6">
        <img
          alt="Rectangle1722"
          src="/playground_assets/rectangle1722-7li6.svg"
          className="home-rectangle028"
        />
        <img
          alt="Rectangle1723"
          src="/playground_assets/rectangle1723-q68s.svg"
          className="home-rectangle029"
        />
        <span className="home-text140">
          <span>회사 B</span>
        </span>
        <span className="home-text142">
          <span>회사 C</span>
        </span>
        <img
          alt="Rectangle1726"
          src="/playground_assets/rectangle1726-rpiw.svg"
          className="home-rectangle030"
        />
        <img
          alt="Line1727"
          src="/playground_assets/line1727-fd2t.svg"
          className="home-line07"
        />
        <img
          alt="Shape1728"
          src="/playground_assets/shape1728-hi3w.svg"
          className="home-shape077"
        />
        <img
          alt="Rectangle1729"
          src="/playground_assets/rectangle1729-lon-200h.png"
          className="home-rectangle031"
        />
        <span className="home-text144">
          <span>Overview</span>
        </span>
        <img
          alt="Rectangle1731"
          src="/playground_assets/rectangle1731-ev5.svg"
          className="home-rectangle032"
        />
        <img
          alt="Rectangle1732"
          src="/playground_assets/rectangle1732-61x.svg"
          className="home-rectangle033"
        />
        <span className="home-text146">
          <span>Annual Sales Ratio</span>
        </span>
        <span className="home-text148">
          <span>75%</span>
        </span>
        <div className="home-maskgroup10"></div>
        <img
          alt="Line1737"
          src="/playground_assets/line1737-bzoh.svg"
          className="home-line08"
        />
        <img
          alt="Line1738"
          src="/playground_assets/line1738-obf.svg"
          className="home-line09"
        />
        <span className="home-text150">
          <span>TODAY</span>
        </span>
        <img
          alt="Shape1740"
          src="/playground_assets/shape1740-yxju.svg"
          className="home-shape078"
        />
        <img
          alt="Shape1741"
          src="/playground_assets/shape1741-67m.svg"
          className="home-shape079"
        />
        <span className="home-text152">
          <span>
            연매출 7억 이상 자연어처리 관련 기업은 회사 C, 회사 D, 회사 E가
            있습니다.
          </span>
        </span>
        <span className="home-text154">
          <span>DOC 28 min ago</span>
        </span>
        <span className="home-text156">
          <span>DOC 28 min ago</span>
        </span>
        <img
          alt="Circle1745"
          src="/playground_assets/circle1745-0j2-200h.png"
          className="home-circle23"
        />
        <img
          alt="Circle1746"
          src="/playground_assets/circle1746-cli9-200h.png"
          className="home-circle24"
        />
        <img
          alt="Rectangle1747"
          src="/playground_assets/rectangle1747-j149.svg"
          className="home-rectangle034"
        />
        <span className="home-text158">
          <span>회사 A</span>
        </span>
        <span className="home-text160">
          <span>그 중에서 연매출 7억 이상 기업만 보여줘</span>
        </span>
        <img
          alt="Shape1750"
          src="/playground_assets/shape1750-9tal.svg"
          className="home-shape080"
        />
        <img
          alt="Shape1751"
          src="/playground_assets/shape1751-pv9.svg"
          className="home-shape081"
        />
        <span className="home-text162">
          <span>June</span>
        </span>
        <span className="home-text164">
          <span>July</span>
        </span>
        <span className="home-text166">
          <span>Aug</span>
        </span>
        <span className="home-text168">
          <span>Sept</span>
        </span>
        <span className="home-text170">
          <span>Oct</span>
        </span>
        <span className="home-text172">
          <span>Nov</span>
        </span>
        <span className="home-text174">
          <span>Dec</span>
        </span>
        <div className="home-group08">
          <img
            alt="Shape1760"
            src="/playground_assets/shape1760-0f1t.svg"
            className="home-shape082"
          />
          <img
            alt="Shape1761"
            src="/playground_assets/shape1761-l6v.svg"
            className="home-shape083"
          />
        </div>
        <img
          alt="Shape1762"
          src="/playground_assets/shape1762-av1m.svg"
          className="home-shape084"
        />
        <img
          alt="Shape1763"
          src="/playground_assets/shape1763-62e7.svg"
          className="home-shape085"
        />
        <img
          alt="Shape1764"
          src="/playground_assets/shape1764-v4c.svg"
          className="home-shape086"
        />
        <img
          alt="Shape1765"
          src="/playground_assets/shape1765-kcc.svg"
          className="home-shape087"
        />
        <img
          alt="Shape1766"
          src="/playground_assets/shape1766-4hz.svg"
          className="home-shape088"
        />
        <img
          alt="Shape1767"
          src="/playground_assets/shape1767-tv3g.svg"
          className="home-shape089"
        />
        <img
          alt="Shape1768"
          src="/playground_assets/shape1768-ufsd.svg"
          className="home-shape090"
        />
        <img
          alt="Shape1769"
          src="/playground_assets/shape1769-4ny.svg"
          className="home-shape091"
        />
        <img
          alt="Rectangle1770"
          src="/playground_assets/rectangle1770-gw5r.svg"
          className="home-rectangle035"
        />
        <img
          alt="Rectangle1771"
          src="/playground_assets/rectangle1771-cjgbl.svg"
          className="home-rectangle036"
        />
        <span className="home-text176">
          <span>회사 A</span>
        </span>
        <img
          alt="Rectangle1773"
          src="/playground_assets/rectangle1773-a109.svg"
          className="home-rectangle037"
        />
        <span className="home-text178">
          <span>Annual Sales Ratio</span>
        </span>
        <span className="home-text180">
          <span>75%</span>
        </span>
        <div className="home-maskgroup11"></div>
        <img
          alt="Shape1778"
          src="/playground_assets/shape1778-fz2c.svg"
          className="home-shape092"
        />
        <img
          alt="Shape1779"
          src="/playground_assets/shape1779-by1l.svg"
          className="home-shape093"
        />
        <span className="home-text182">
          <span>June</span>
        </span>
        <span className="home-text184">
          <span>July</span>
        </span>
        <span className="home-text186">
          <span>Aug</span>
        </span>
        <span className="home-text188">
          <span>Sept</span>
        </span>
        <span className="home-text190">
          <span>Oct</span>
        </span>
        <span className="home-text192">
          <span>Nov</span>
        </span>
        <span className="home-text194">
          <span>Dec</span>
        </span>
        <div className="home-group09">
          <img
            alt="Shape1788"
            src="/playground_assets/shape1788-5yd9.svg"
            className="home-shape094"
          />
          <img
            alt="Shape1789"
            src="/playground_assets/shape1789-v2a.svg"
            className="home-shape095"
          />
        </div>
        <img
          alt="Shape1790"
          src="/playground_assets/shape1790-u0e.svg"
          className="home-shape096"
        />
        <img
          alt="Shape1791"
          src="/playground_assets/shape1791-qpc8.svg"
          className="home-shape097"
        />
        <img
          alt="Shape1792"
          src="/playground_assets/shape1792-3u4.svg"
          className="home-shape098"
        />
        <img
          alt="Shape1793"
          src="/playground_assets/shape1793-myh6.svg"
          className="home-shape099"
        />
        <img
          alt="Shape1794"
          src="/playground_assets/shape1794-w2xn.svg"
          className="home-shape100"
        />
        <img
          alt="Shape1795"
          src="/playground_assets/shape1795-nx3s.svg"
          className="home-shape101"
        />
        <img
          alt="Shape1796"
          src="/playground_assets/shape1796-dvjv.svg"
          className="home-shape102"
        />
        <img
          alt="Shape1797"
          src="/playground_assets/shape1797-w95k.svg"
          className="home-shape103"
        />
        <img
          alt="Rectangle1798"
          src="/playground_assets/rectangle1798-b54na.svg"
          className="home-rectangle038"
        />
        <img
          alt="Rectangle1799"
          src="/playground_assets/rectangle1799-3zsl.svg"
          className="home-rectangle039"
        />
        <img
          alt="Rectangle1800"
          src="/playground_assets/rectangle1800-xq5.svg"
          className="home-rectangle040"
        />
        <span className="home-text196">
          <span>Annual Sales Ratio</span>
        </span>
        <span className="home-text198">
          <span>75%</span>
        </span>
        <div className="home-maskgroup12"></div>
        <img
          alt="Shape1805"
          src="/playground_assets/shape1805-krjo.svg"
          className="home-shape104"
        />
        <img
          alt="Shape1806"
          src="/playground_assets/shape1806-k6m.svg"
          className="home-shape105"
        />
        <span className="home-text200">
          <span>June</span>
        </span>
        <span className="home-text202">
          <span>July</span>
        </span>
        <span className="home-text204">
          <span>Aug</span>
        </span>
        <span className="home-text206">
          <span>Sept</span>
        </span>
        <span className="home-text208">
          <span>Oct</span>
        </span>
        <span className="home-text210">
          <span>Nov</span>
        </span>
        <span className="home-text212">
          <span>Dec</span>
        </span>
        <div className="home-group10">
          <img
            alt="Shape1815"
            src="/playground_assets/shape1815-v73w.svg"
            className="home-shape106"
          />
          <img
            alt="Shape1816"
            src="/playground_assets/shape1816-144r.svg"
            className="home-shape107"
          />
        </div>
        <img
          alt="Shape1817"
          src="/playground_assets/shape1817-w45g.svg"
          className="home-shape108"
        />
        <img
          alt="Shape1818"
          src="/playground_assets/shape1818-hbs1.svg"
          className="home-shape109"
        />
        <img
          alt="Shape1819"
          src="/playground_assets/shape1819-v5c6.svg"
          className="home-shape110"
        />
        <img
          alt="Shape1820"
          src="/playground_assets/shape1820-4f4c.svg"
          className="home-shape111"
        />
        <img
          alt="Shape1821"
          src="/playground_assets/shape1821-f85t.svg"
          className="home-shape112"
        />
        <img
          alt="Shape1822"
          src="/playground_assets/shape1822-r5ab.svg"
          className="home-shape113"
        />
        <img
          alt="Shape1823"
          src="/playground_assets/shape1823-uwi.svg"
          className="home-shape114"
        />
        <img
          alt="Shape1824"
          src="/playground_assets/shape1824-fcjs.svg"
          className="home-shape115"
        />
        <img
          alt="Rectangle1825"
          src="/playground_assets/rectangle1825-2gnc.svg"
          className="home-rectangle041"
        />
        <span className="home-text214">
          <span>회사 E</span>
        </span>
        <img
          alt="Rectangle1827"
          src="/playground_assets/rectangle1827-1g7j.svg"
          className="home-rectangle042"
        />
        <span className="home-text216">
          <span>Annual Sales Ratio</span>
        </span>
        <span className="home-text218">
          <span>107%</span>
        </span>
        <div className="home-maskgroup13"></div>
        <img
          alt="Shape1832"
          src="/playground_assets/shape1832-yka9.svg"
          className="home-shape116"
        />
        <img
          alt="Shape1833"
          src="/playground_assets/shape1833-1esc.svg"
          className="home-shape117"
        />
        <span className="home-text220">
          <span>June</span>
        </span>
        <span className="home-text222">
          <span>July</span>
        </span>
        <span className="home-text224">
          <span>Aug</span>
        </span>
        <span className="home-text226">
          <span>Sept</span>
        </span>
        <span className="home-text228">
          <span>Oct</span>
        </span>
        <span className="home-text230">
          <span>Nov</span>
        </span>
        <span className="home-text232">
          <span>Dec</span>
        </span>
        <div className="home-group11">
          <img
            alt="Shape1842"
            src="/playground_assets/shape1842-5d2.svg"
            className="home-shape118"
          />
          <img
            alt="Shape1843"
            src="/playground_assets/shape1843-5bye.svg"
            className="home-shape119"
          />
        </div>
        <img
          alt="Shape1844"
          src="/playground_assets/shape1844-1ouf.svg"
          className="home-shape120"
        />
        <img
          alt="Shape1845"
          src="/playground_assets/shape1845-3si.svg"
          className="home-shape121"
        />
        <img
          alt="Shape1846"
          src="/playground_assets/shape1846-ptqxk.svg"
          className="home-shape122"
        />
        <img
          alt="Shape1847"
          src="/playground_assets/shape1847-t1dc.svg"
          className="home-shape123"
        />
        <img
          alt="Shape1848"
          src="/playground_assets/shape1848-aih.svg"
          className="home-shape124"
        />
        <img
          alt="Shape1849"
          src="/playground_assets/shape1849-kzbu.svg"
          className="home-shape125"
        />
        <img
          alt="Shape1850"
          src="/playground_assets/shape1850-9yq9.svg"
          className="home-shape126"
        />
        <img
          alt="Shape1851"
          src="/playground_assets/shape1851-hal.svg"
          className="home-shape127"
        />
        <img
          alt="Rectangle1852"
          src="/playground_assets/rectangle1852-6vl8.svg"
          className="home-rectangle043"
        />
        <img
          alt="Rectangle1853"
          src="/playground_assets/rectangle1853-uf8w.svg"
          className="home-rectangle044"
        />
        <span className="home-text234">
          <span>회사 A</span>
        </span>
        <img
          alt="Rectangle1855"
          src="/playground_assets/rectangle1855-pvp.svg"
          className="home-rectangle045"
        />
        <span className="home-text236">
          <span>Annual Sales Ratio</span>
        </span>
        <span className="home-text238">
          <span>75%</span>
        </span>
        <div className="home-maskgroup14"></div>
        <img
          alt="Shape1860"
          src="/playground_assets/shape1860-olru.svg"
          className="home-shape128"
        />
        <img
          alt="Shape1861"
          src="/playground_assets/shape1861-3du.svg"
          className="home-shape129"
        />
        <span className="home-text240">
          <span>June</span>
        </span>
        <span className="home-text242">
          <span>July</span>
        </span>
        <span className="home-text244">
          <span>Aug</span>
        </span>
        <span className="home-text246">
          <span>Sept</span>
        </span>
        <span className="home-text248">
          <span>Oct</span>
        </span>
        <span className="home-text250">
          <span>Nov</span>
        </span>
        <span className="home-text252">
          <span>Dec</span>
        </span>
        <div className="home-group12">
          <img
            alt="Shape1870"
            src="/playground_assets/shape1870-nwzj.svg"
            className="home-shape130"
          />
          <img
            alt="Shape1871"
            src="/playground_assets/shape1871-dz19.svg"
            className="home-shape131"
          />
        </div>
        <img
          alt="Shape1872"
          src="/playground_assets/shape1872-zqv.svg"
          className="home-shape132"
        />
        <img
          alt="Shape1873"
          src="/playground_assets/shape1873-8k9.svg"
          className="home-shape133"
        />
        <img
          alt="Shape1874"
          src="/playground_assets/shape1874-zmgr.svg"
          className="home-shape134"
        />
        <img
          alt="Shape1875"
          src="/playground_assets/shape1875-iso9.svg"
          className="home-shape135"
        />
        <img
          alt="Shape1876"
          src="/playground_assets/shape1876-h7ma.svg"
          className="home-shape136"
        />
        <img
          alt="Shape1877"
          src="/playground_assets/shape1877-vi2d.svg"
          className="home-shape137"
        />
        <img
          alt="Shape1878"
          src="/playground_assets/shape1878-08a4.svg"
          className="home-shape138"
        />
        <img
          alt="Shape1879"
          src="/playground_assets/shape1879-saxw.svg"
          className="home-shape139"
        />
        <img
          alt="Rectangle1880"
          src="/playground_assets/rectangle1880-782q.svg"
          className="home-rectangle046"
        />
        <img
          alt="Rectangle1881"
          src="/playground_assets/rectangle1881-m78f.svg"
          className="home-rectangle047"
        />
        <img
          alt="Rectangle1882"
          src="/playground_assets/rectangle1882-zv0v.svg"
          className="home-rectangle048"
        />
        <span className="home-text254">
          <span>Annual Sales Ratio</span>
        </span>
        <span className="home-text256">
          <span>75%</span>
        </span>
        <div className="home-maskgroup15"></div>
        <img
          alt="Shape1887"
          src="/playground_assets/shape1887-ej8n.svg"
          className="home-shape140"
        />
        <img
          alt="Shape1888"
          src="/playground_assets/shape1888-fq4q.svg"
          className="home-shape141"
        />
        <span className="home-text258">
          <span>June</span>
        </span>
        <span className="home-text260">
          <span>July</span>
        </span>
        <span className="home-text262">
          <span>Aug</span>
        </span>
        <span className="home-text264">
          <span>Sept</span>
        </span>
        <span className="home-text266">
          <span>Oct</span>
        </span>
        <span className="home-text268">
          <span>Nov</span>
        </span>
        <span className="home-text270">
          <span>Dec</span>
        </span>
        <div className="home-group13">
          <img
            alt="Shape1897"
            src="/playground_assets/shape1897-ou2f.svg"
            className="home-shape142"
          />
          <img
            alt="Shape1898"
            src="/playground_assets/shape1898-p1nt.svg"
            className="home-shape143"
          />
        </div>
        <img
          alt="Shape1899"
          src="/playground_assets/shape1899-gzs7.svg"
          className="home-shape144"
        />
        <img
          alt="Shape1900"
          src="/playground_assets/shape1900-fhwb.svg"
          className="home-shape145"
        />
        <img
          alt="Shape1901"
          src="/playground_assets/shape1901-skkg.svg"
          className="home-shape146"
        />
        <img
          alt="Shape1902"
          src="/playground_assets/shape1902-cjrk.svg"
          className="home-shape147"
        />
        <img
          alt="Shape1903"
          src="/playground_assets/shape1903-m.svg"
          className="home-shape148"
        />
        <img
          alt="Shape1904"
          src="/playground_assets/shape1904-9acq.svg"
          className="home-shape149"
        />
        <img
          alt="Shape1905"
          src="/playground_assets/shape1905-wpls.svg"
          className="home-shape150"
        />
        <img
          alt="Shape1906"
          src="/playground_assets/shape1906-apno.svg"
          className="home-shape151"
        />
        <img
          alt="Rectangle1907"
          src="/playground_assets/rectangle1907-tp.svg"
          className="home-rectangle049"
        />
        <span className="home-text272">
          <span>회사 D</span>
        </span>
        <img
          alt="Rectangle1909"
          src="/playground_assets/rectangle1909-uniuq.svg"
          className="home-rectangle050"
        />
        <span className="home-text274">
          <span>Annual Sales Ratio</span>
        </span>
        <span className="home-text276">
          <span>95%</span>
        </span>
        <div className="home-maskgroup16"></div>
        <img
          alt="Shape1914"
          src="/playground_assets/shape1914-uo9j.svg"
          className="home-shape152"
        />
        <img
          alt="Shape1915"
          src="/playground_assets/shape1915-rog7.svg"
          className="home-shape153"
        />
        <span className="home-text278">
          <span>June</span>
        </span>
        <span className="home-text280">
          <span>July</span>
        </span>
        <span className="home-text282">
          <span>Aug</span>
        </span>
        <span className="home-text284">
          <span>Sept</span>
        </span>
        <span className="home-text286">
          <span>Oct</span>
        </span>
        <span className="home-text288">
          <span>Nov</span>
        </span>
        <span className="home-text290">
          <span>Dec</span>
        </span>
        <div className="home-group14">
          <img
            alt="Shape1924"
            src="/playground_assets/shape1924-iyp5.svg"
            className="home-shape154"
          />
          <img
            alt="Shape1925"
            src="/playground_assets/shape1925-5mi.svg"
            className="home-shape155"
          />
        </div>
        <img
          alt="Shape1926"
          src="/playground_assets/shape1926-xw8m.svg"
          className="home-shape156"
        />
        <img
          alt="Shape1927"
          src="/playground_assets/shape1927-p8ju.svg"
          className="home-shape157"
        />
        <img
          alt="Shape1928"
          src="/playground_assets/shape1928-oqbr.svg"
          className="home-shape158"
        />
        <img
          alt="Shape1929"
          src="/playground_assets/shape1929-wqdh.svg"
          className="home-shape159"
        />
        <img
          alt="Shape1930"
          src="/playground_assets/shape1930-9lcfy.svg"
          className="home-shape160"
        />
        <img
          alt="Shape1931"
          src="/playground_assets/shape1931-vd58.svg"
          className="home-shape161"
        />
        <img
          alt="Shape1932"
          src="/playground_assets/shape1932-u8xr.svg"
          className="home-shape162"
        />
        <img
          alt="Shape1933"
          src="/playground_assets/shape1933-7p9l.svg"
          className="home-shape163"
        />
        <div className="home-patient-dashboard-chats-light-theme1">
          <img
            alt="Rectangle1935"
            src="/playground_assets/rectangle1935-3bv.svg"
            className="home-rectangle051"
          />
          <div className="home-group15">
            <img
              alt="Rectangle1937"
              src="/playground_assets/rectangle1937-1bua.svg"
              className="home-rectangle052"
            />
          </div>
          <img
            alt="Shape1938"
            src="/playground_assets/shape1938-zo04.svg"
            className="home-shape164"
          />
          <img
            alt="Shape1939"
            src="/playground_assets/shape1939-6si.svg"
            className="home-shape165"
          />
          <img
            alt="Shape1940"
            src="/playground_assets/shape1940-r6ya.svg"
            className="home-shape166"
          />
          <img
            alt="Shape1941"
            src="/playground_assets/shape1941-ylrb.svg"
            className="home-shape167"
          />
          <img
            alt="Shape1942"
            src="/playground_assets/shape1942-xxu.svg"
            className="home-shape168"
          />
          <img
            alt="Shape1943"
            src="/playground_assets/shape1943-5zcv.svg"
            className="home-shape169"
          />
          <img
            alt="Shape1944"
            src="/playground_assets/shape1944-emh1.svg"
            className="home-shape170"
          />
          <img
            alt="Shape1945"
            src="/playground_assets/shape1945-dfb.svg"
            className="home-shape171"
          />
          <img
            alt="Shape1946"
            src="/playground_assets/shape1946-d0uk.svg"
            className="home-shape172"
          />
          <img
            alt="Shape1947"
            src="/playground_assets/shape1947-segq.svg"
            className="home-shape173"
          />
          <img
            alt="Shape1948"
            src="/playground_assets/shape1948-p9jp.svg"
            className="home-shape174"
          />
          <img
            alt="Shape1949"
            src="/playground_assets/shape1949-f0ye.svg"
            className="home-shape175"
          />
          <img
            alt="Line1950"
            src="/playground_assets/line1950-748m.svg"
            className="home-line10"
          />
          <img
            alt="Circle1951"
            src="/playground_assets/circle1951-z3cm-200h.png"
            className="home-circle25"
          />
          <img
            alt="Circle1952"
            src="/playground_assets/circle1952-2qw-200h.png"
            className="home-circle26"
          />
          <div className="home-group41">
            <img
              alt="Shape1954"
              src="/playground_assets/shape1954-79x.svg"
              className="home-shape176"
            />
            <img
              alt="Shape1955"
              src="/playground_assets/shape1955-ifq.svg"
              className="home-shape177"
            />
          </div>
          <img
            alt="Circle1956"
            src="/playground_assets/circle1956-hwq-200h.png"
            className="home-circle27"
          />
          <div className="home-notification-bell1">
            <img
              alt="Shape1958"
              src="/playground_assets/shape1958-fakc.svg"
              className="home-shape178"
            />
            <img
              alt="Shape1959"
              src="/playground_assets/shape1959-aq4.svg"
              className="home-shape179"
            />
            <img
              alt="Shape1960"
              src="/playground_assets/shape1960-fzdf.svg"
              className="home-shape180"
            />
          </div>
          <img
            alt="Line1963"
            src="/playground_assets/line1963-wwun.svg"
            className="home-line11"
          />
          <img
            alt="Line1964"
            src="/playground_assets/line1964-hles.svg"
            className="home-line12"
          />
          <img
            alt="Rectangle1965"
            src="/playground_assets/rectangle1965-q4os.svg"
            className="home-rectangle053"
          />
          <img
            alt="Shape1966"
            src="/playground_assets/shape1966-79so.svg"
            className="home-shape181"
          />
          <img
            alt="Shape1969"
            src="/playground_assets/shape1969-5icp.svg"
            className="home-shape182"
          />
          <img
            alt="Shape1970"
            src="/playground_assets/shape1970-qxpi.svg"
            className="home-shape183"
          />
          <img
            alt="Shape1971"
            src="/playground_assets/shape1971-cztg.svg"
            className="home-shape184"
          />
          <div>
            <img
              alt="Shape1973"
              src="/playground_assets/shape1973-y14.svg"
              className="home-shape185"
            />
            <img
              alt="Shape1974"
              src="/playground_assets/shape1974-ziv4.svg"
              className="home-shape186"
            />
            <img
              alt="Shape1975"
              src="/playground_assets/shape1975-k4mg.svg"
              className="home-shape187"
            />
            <img
              alt="Shape1976"
              src="/playground_assets/shape1976-38en.svg"
              className="home-shape188"
            />
            <img
              alt="Shape1977"
              src="/playground_assets/shape1977-qarp.svg"
              className="home-shape189"
            />
          </div>
          <img
            alt="Shape1978"
            src="/playground_assets/shape1978-t4vl.svg"
            className="home-shape190"
          />
          <img
            alt="Shape1984"
            src="/playground_assets/shape1984-j1xe.svg"
            className="home-shape191"
          />
          <span className="home-text292">
            <span>Chats</span>
          </span>
          <span className="home-text294">
            <span>Apply Dark Theme</span>
          </span>
          <span className="home-text296">
            <span>Ola Boluwatife</span>
          </span>
          <span className="home-text298">
            <span>Samsung electronics</span>
          </span>
          <span className="home-text300">
            <span>Search pathology results</span>
          </span>
          <span className="home-text302">
            <span>Chats</span>
          </span>
          <span className="home-text304">
            <span>Settings</span>
          </span>
          <span className="home-text306">
            <span>+234 92 928 2891 +234 60 621 2098</span>
          </span>
          <span className="home-text308">
            <span>Logouts</span>
          </span>
          <span className="home-text310">
            <span>Emergency Hotlines:</span>
          </span>
          <span className="home-text312">
            <span>ACCOUNT</span>
          </span>
          <img
            alt="Shape1998"
            src="/playground_assets/shape1998-nww.svg"
            className="home-shape192"
          />
          <div className="home-group71">
            <img
              alt="Shape1100"
              src="/playground_assets/shape1100-urss.svg"
              className="home-shape193"
            />
            <img
              alt="Shape1100"
              src="/playground_assets/shape1100-tlvr.svg"
              className="home-shape194"
            />
          </div>
          <img
            alt="Shape1100"
            src="/playground_assets/shape1100-n8bo.svg"
            className="home-shape195"
          />
          <img
            alt="Line1100"
            src="/playground_assets/line1100-x6vi.svg"
            className="home-line13"
          />
          <img
            alt="Line1100"
            src="/playground_assets/line1100-iuga.svg"
            className="home-line14"
          />
          <img
            alt="Line1100"
            src="/playground_assets/line1100-tgiq.svg"
            className="home-line15"
          />
          <img
            alt="Circle1100"
            src="/playground_assets/circle1100-f868-200h.png"
            className="home-circle28"
          />
          <img
            alt="Circle1100"
            src="/playground_assets/circle1100-oz2t-200h.png"
            className="home-circle29"
          />
          <img
            alt="Circle1100"
            src="/playground_assets/circle1100-602-200h.png"
            className="home-circle30"
          />
          <img
            alt="Shape1100"
            src="/playground_assets/shape1100-8k8.svg"
            className="home-shape196"
          />
          <img
            alt="Shape1101"
            src="/playground_assets/shape1101-dv5.svg"
            className="home-shape197"
          />
          <img
            alt="Shape1101"
            src="/playground_assets/shape1101-grg.svg"
            className="home-shape198"
          />
          <img
            alt="Shape1101"
            src="/playground_assets/shape1101-4e4b.svg"
            className="home-shape199"
          />
          <img
            alt="Shape1101"
            src="/playground_assets/shape1101-f3me.svg"
            className="home-shape200"
          />
          <img
            alt="Shape1101"
            src="/playground_assets/shape1101-8kv.svg"
            className="home-shape201"
          />
          <img
            alt="Shape1101"
            src="/playground_assets/shape1101-kpaw.svg"
            className="home-shape202"
          />
          <img
            alt="Shape1101"
            src="/playground_assets/shape1101-a9w0n.svg"
            className="home-shape203"
          />
          <img
            alt="Shape1102"
            src="/playground_assets/shape1102-nv3j.svg"
            className="home-shape204"
          />
          <img
            alt="Rectangle1102"
            src="/playground_assets/rectangle1102-kcch.svg"
            className="home-rectangle054"
          />
          <img
            alt="Rectangle1102"
            src="/playground_assets/rectangle1102-mx4xm.svg"
            className="home-rectangle055"
          />
          <img
            alt="Rectangle1102"
            src="/playground_assets/rectangle1102-3vrb.svg"
            className="home-rectangle056"
          />
          <img
            alt="Rectangle1102"
            src="/playground_assets/rectangle1102-gycf.svg"
            className="home-rectangle057"
          />
          <span className="home-text314">
            <span>Dr. Ibrahim Yekeni</span>
          </span>
          <span className="home-text316">
            <span>DOC 28 min ago</span>
          </span>
          <span className="home-text318">
            <span>ME 28 min ago</span>
          </span>
          <span className="home-text320">
            <span>
              <span>
                자연어 처리 관련 기업은 회사 A,
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <br></br>
              <span>회사 B, 회사 C 외 5개 회사가 있습니다.</span>
            </span>
          </span>
          <span className="home-text325">
            <span>
              <span>
                회사 C는 자연어처리 기술을 활용해 금융권의
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <br></br>
              <span>비정형 데이터 자산화 서비스를 제공하는 기업입니다.</span>
            </span>
          </span>
          <span className="home-text330">
            <span>기술 키워드 : 자연어 처리, 인공 지능, 교육, 아동</span>
          </span>
          <span className="home-text332">
            <span>연매출 : 8.2 억, 성장률 : 75 %</span>
          </span>
          <span className="home-text334">
            <span>자연어 처리 관련 기업 찾아줘</span>
          </span>
          <span className="home-text336">
            <span>Start typing here</span>
          </span>
          <span className="home-text338">
            <span>Active 50min ago</span>
          </span>
          <span className="home-text340">1</span>
          <span className="home-text341">2</span>
          <span className="home-text342">1</span>
          <span className="home-text343">
            <span>input text</span>
          </span>
          <span className="home-text345">X</span>
          <img
            alt="KakaoTalkPhoto2022120721342811104"
            src="/playground_assets/kakaotalkphoto2022120721342811104-y23-200w.png"
            className="home-kakao-talk-photo2022120721342814"
          />
          <span className="home-text346">H</span>
          <span className="home-text347">O</span>
          <span className="home-text348">T</span>
          <span className="home-text349">S</span>
          <span className="home-text350">I</span>
          <span className="home-text351">H</span>
          <span className="home-text352">X</span>
          <img
            alt="Shape1105"
            src="/playground_assets/shape1105-ghgn.svg"
            className="home-shape205"
          />
          <img
            alt="Shape1105"
            src="/playground_assets/shape1105-obvj.svg"
            className="home-shape206"
          />
          <img
            alt="Shape1105"
            src="/playground_assets/shape1105-16g8.svg"
            className="home-shape207"
          />
          <img
            alt="Shape1106"
            src="/playground_assets/shape1106-3tjd.svg"
            className="home-shape208"
          />
          <img
            alt="Shape1106"
            src="/playground_assets/shape1106-np78.svg"
            className="home-shape209"
          />
          <img
            alt="Shape1106"
            src="/playground_assets/shape1106-755o.svg"
            className="home-shape210"
          />
          <img
            alt="Shape1107"
            src="/playground_assets/shape1107-lsr.svg"
            className="home-shape211"
          />
          <img
            alt="Shape1107"
            src="/playground_assets/shape1107-d1s.svg"
            className="home-shape212"
          />
          <img
            alt="Rectangle1107"
            src="/playground_assets/rectangle1107-d0d.svg"
            className="home-rectangle058"
          />
          <img
            alt="Shape1108"
            src="/playground_assets/shape1108-k11n.svg"
            className="home-shape213"
          />
          <span className="home-text353">
            <span>회사 B</span>
          </span>
          <span className="home-text355">
            <span>회사 C</span>
          </span>
          <span className="home-text357">
            <span>회사 A</span>
          </span>
          <span className="home-text359">
            <span>
              <span>
                회사 E는 자연어처리 기술을 활용해 금융권의
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <br></br>
              <span>비정형 데이터 자산화 서비스를 제공하는 기업입니다.</span>
            </span>
          </span>
          <span className="home-text364">
            <span>기술 키워드 : 자연어 처리, 인공 지능, 교육, 아동</span>
          </span>
          <span className="home-text366">
            <span>연매출 : 18.7 억, 성장률 : 107 %</span>
          </span>
          <span className="home-text368">
            <span>
              <span>
                회사 D는 자연어처리 기술을 활용해 금융권의
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <br></br>
              <span>비정형 데이터 자산화 서비스를 제공하는 기업입니다.</span>
            </span>
          </span>
          <span className="home-text373">
            <span>기술 키워드 : 자연어 처리, 인공 지능, 교육, 아동</span>
          </span>
          <span className="home-text375">
            <span>연매출 : 10.4 억, 성장률 : 95 %</span>
          </span>
        </div>
      </div>
      <div className="home-desktop11">
        <img
          alt="Rectangle191517"
          src="/playground_assets/rectangle191517-mao6-200h.png"
          className="home-rectangle19"
        />
        <img
          alt="Rectangle211518"
          src="/playground_assets/rectangle211518-sayw-600h.png"
          className="home-rectangle21"
        />
        <img
          alt="Rectangle1519"
          src="/playground_assets/rectangle1519-qvxs.svg"
          className="home-rectangle059"
        />
        <span className="home-text377">
          <span>회사 A</span>
        </span>
        <span className="home-text379">O</span>
        <span className="home-text380">T</span>
        <span className="home-text381">S</span>
        <span className="home-text382">I</span>
        <span className="home-text383">H</span>
        <img
          alt="Shape1526"
          src="/playground_assets/shape1526-ckvm.svg"
          className="home-shape214"
        />
        <img
          alt="Line1530"
          src="/playground_assets/line1530-8hom.svg"
          className="home-line16"
        />
        <img
          alt="Shape1531"
          src="/playground_assets/shape1531-at6.svg"
          className="home-shape215"
        />
        <img
          alt="Rectangle1532"
          src="/playground_assets/rectangle1532-ux6p-200h.png"
          className="home-rectangle060"
        />
        <span className="home-text384">
          <span>Overview</span>
        </span>
        <img
          alt="Line1534"
          src="/playground_assets/line1534-b1b.svg"
          className="home-line17"
        />
        <img
          alt="Line1535"
          src="/playground_assets/line1535-zni.svg"
          className="home-line18"
        />
        <span className="home-text386">
          <span>TODAY</span>
        </span>
        <img
          alt="Shape1537"
          src="/playground_assets/shape1537-vqzr.svg"
          className="home-shape216"
        />
        <img
          alt="Shape1538"
          src="/playground_assets/shape1538-g29.svg"
          className="home-shape217"
        />
        <span className="home-text388">
          <span>
            회사 A와 유사한 기업은 회사 C, 회사 D, 회사 E, 회사 F, 회사 G
            입니다.
          </span>
        </span>
        <span className="home-text390">
          <span>DOC 28 min ago</span>
        </span>
        <span className="home-text392">
          <span>DOC 28 min ago</span>
        </span>
        <img
          alt="Circle1542"
          src="/playground_assets/circle1542-alzm-200h.png"
          className="home-circle31"
        />
        <img
          alt="Circle1543"
          src="/playground_assets/circle1543-sy7-200h.png"
          className="home-circle32"
        />
        <span className="home-text394">
          <span>회사 A와 유사한 기업 찾아줘</span>
        </span>
        <img
          alt="Rectangle1545"
          src="/playground_assets/rectangle1545-qzmb.svg"
          className="home-rectangle061"
        />
        <span className="home-text396">
          <span>회사 C</span>
        </span>
        <img
          alt="Rectangle221547"
          src="/playground_assets/rectangle221547-lfsl.svg"
          className="home-rectangle22"
        />
        <img
          alt="Rectangle1548"
          src="/playground_assets/rectangle1548-yl9v.svg"
          className="home-rectangle062"
        />
        <span className="home-text398">
          <span>회사 C</span>
        </span>
        <img
          alt="Rectangle1550"
          src="/playground_assets/rectangle1550-ztz9.svg"
          className="home-rectangle063"
        />
        <span className="home-text400">
          <span>회사 C</span>
        </span>
        <img
          alt="Rectangle241552"
          src="/playground_assets/rectangle241552-q6b.svg"
          className="home-rectangle24"
        />
        <img
          alt="Rectangle1553"
          src="/playground_assets/rectangle1553-o59m.svg"
          className="home-rectangle064"
        />
        <span className="home-text402">
          <span>회사 D</span>
        </span>
        <img
          alt="Rectangle1555"
          src="/playground_assets/rectangle1555-w16v.svg"
          className="home-rectangle065"
        />
        <span className="home-text404">
          <span>회사 C</span>
        </span>
        <img
          alt="Rectangle281557"
          src="/playground_assets/rectangle281557-pbvr.svg"
          className="home-rectangle28"
        />
        <img
          alt="Rectangle1558"
          src="/playground_assets/rectangle1558-6f0o.svg"
          className="home-rectangle066"
        />
        <span className="home-text406">
          <span>회사 G</span>
        </span>
        <img
          alt="Rectangle261560"
          src="/playground_assets/rectangle261560-0tph.svg"
          className="home-rectangle26"
        />
        <img
          alt="Rectangle1561"
          src="/playground_assets/rectangle1561-r4br.svg"
          className="home-rectangle067"
        />
        <span className="home-text408">
          <span>회사 E</span>
        </span>
        <img
          alt="Rectangle271563"
          src="/playground_assets/rectangle271563-5pd5.svg"
          className="home-rectangle27"
        />
        <img
          alt="Rectangle1564"
          src="/playground_assets/rectangle1564-u4icm.svg"
          className="home-rectangle068"
        />
        <span className="home-text410">
          <span>회사 F</span>
        </span>
        <div className="home-patient-dashboard-chats-light-theme2">
          <img
            alt="Rectangle1567"
            src="/playground_assets/rectangle1567-17m.svg"
            className="home-rectangle069"
          />
          <div className="home-group16">
            <img
              alt="Rectangle1569"
              src="/playground_assets/rectangle1569-gyai.svg"
              className="home-rectangle070"
            />
          </div>
          <img
            alt="Shape1570"
            src="/playground_assets/shape1570-hqhv.svg"
            className="home-shape218"
          />
          <img
            alt="Shape1571"
            src="/playground_assets/shape1571-7m0g.svg"
            className="home-shape219"
          />
          <img
            alt="Shape1572"
            src="/playground_assets/shape1572-4f0l.svg"
            className="home-shape220"
          />
          <img
            alt="Shape1573"
            src="/playground_assets/shape1573-s3m.svg"
            className="home-shape221"
          />
          <img
            alt="Shape1574"
            src="/playground_assets/shape1574-khp.svg"
            className="home-shape222"
          />
          <img
            alt="Shape1575"
            src="/playground_assets/shape1575-sdq.svg"
            className="home-shape223"
          />
          <img
            alt="Shape1576"
            src="/playground_assets/shape1576-1lbq.svg"
            className="home-shape224"
          />
          <img
            alt="Shape1577"
            src="/playground_assets/shape1577-bsy8.svg"
            className="home-shape225"
          />
          <img
            alt="Shape1578"
            src="/playground_assets/shape1578-75xm.svg"
            className="home-shape226"
          />
          <img
            alt="Shape1579"
            src="/playground_assets/shape1579-hfl.svg"
            className="home-shape227"
          />
          <img
            alt="Shape1580"
            src="/playground_assets/shape1580-8hoo.svg"
            className="home-shape228"
          />
          <img
            alt="Shape1581"
            src="/playground_assets/shape1581-dnu.svg"
            className="home-shape229"
          />
          <img
            alt="Line1582"
            src="/playground_assets/line1582-1gxk.svg"
            className="home-line19"
          />
          <img
            alt="Circle1583"
            src="/playground_assets/circle1583-x55-200h.png"
            className="home-circle33"
          />
          <img
            alt="Circle1584"
            src="/playground_assets/circle1584-2sr-200h.png"
            className="home-circle34"
          />
          <div className="home-group42">
            <img
              alt="Shape1586"
              src="/playground_assets/shape1586-jd8.svg"
              className="home-shape230"
            />
            <img
              alt="Shape1587"
              src="/playground_assets/shape1587-pdmw.svg"
              className="home-shape231"
            />
          </div>
          <img
            alt="Circle1588"
            src="/playground_assets/circle1588-m6wj-200h.png"
            className="home-circle35"
          />
          <div className="home-notification-bell2">
            <img
              alt="Shape1590"
              src="/playground_assets/shape1590-dmlh.svg"
              className="home-shape232"
            />
            <img
              alt="Shape1591"
              src="/playground_assets/shape1591-47ep.svg"
              className="home-shape233"
            />
            <img
              alt="Shape1592"
              src="/playground_assets/shape1592-jwlr.svg"
              className="home-shape234"
            />
          </div>
          <img
            alt="Line1595"
            src="/playground_assets/line1595-rz3i.svg"
            className="home-line20"
          />
          <img
            alt="Line1596"
            src="/playground_assets/line1596-23o.svg"
            className="home-line21"
          />
          <img
            alt="Rectangle1597"
            src="/playground_assets/rectangle1597-vyh.svg"
            className="home-rectangle071"
          />
          <img
            alt="Shape1598"
            src="/playground_assets/shape1598-wy8n.svg"
            className="home-shape235"
          />
          <img
            alt="Shape1601"
            src="/playground_assets/shape1601-tik6.svg"
            className="home-shape236"
          />
          <img
            alt="Shape1602"
            src="/playground_assets/shape1602-gls.svg"
            className="home-shape237"
          />
          <img
            alt="Shape1603"
            src="/playground_assets/shape1603-94k.svg"
            className="home-shape238"
          />
          <div>
            <img
              alt="Shape1605"
              src="/playground_assets/shape1605-oif.svg"
              className="home-shape239"
            />
            <img
              alt="Shape1606"
              src="/playground_assets/shape1606-jwsz.svg"
              className="home-shape240"
            />
            <img
              alt="Shape1607"
              src="/playground_assets/shape1607-ddw.svg"
              className="home-shape241"
            />
            <img
              alt="Shape1608"
              src="/playground_assets/shape1608-37np.svg"
              className="home-shape242"
            />
            <img
              alt="Shape1609"
              src="/playground_assets/shape1609-zfdi.svg"
              className="home-shape243"
            />
          </div>
          <img
            alt="Shape1610"
            src="/playground_assets/shape1610-8dio.svg"
            className="home-shape244"
          />
          <img
            alt="Shape1616"
            src="/playground_assets/shape1616-ecyc.svg"
            className="home-shape245"
          />
          <span className="home-text412">
            <span>Chats</span>
          </span>
          <span className="home-text414">
            <span>Apply Dark Theme</span>
          </span>
          <span className="home-text416">
            <span>Ola Boluwatife</span>
          </span>
          <span className="home-text418">
            <span>Samsung electronics</span>
          </span>
          <span className="home-text420">
            <span>Search pathology results</span>
          </span>
          <span className="home-text422">
            <span>Chats</span>
          </span>
          <span className="home-text424">
            <span>Settings</span>
          </span>
          <span className="home-text426">
            <span>+234 92 928 2891 +234 60 621 2098</span>
          </span>
          <span className="home-text428">
            <span>Logouts</span>
          </span>
          <span className="home-text430">
            <span>Emergency Hotlines:</span>
          </span>
          <span className="home-text432">
            <span>ACCOUNT</span>
          </span>
          <img
            alt="Shape1630"
            src="/playground_assets/shape1630-a65a.svg"
            className="home-shape246"
          />
          <div className="home-group72">
            <img
              alt="Shape1632"
              src="/playground_assets/shape1632-9nn.svg"
              className="home-shape247"
            />
            <img
              alt="Shape1633"
              src="/playground_assets/shape1633-4c7.svg"
              className="home-shape248"
            />
          </div>
          <img
            alt="Shape1634"
            src="/playground_assets/shape1634-1f0j.svg"
            className="home-shape249"
          />
          <img
            alt="Line1635"
            src="/playground_assets/line1635-raab.svg"
            className="home-line22"
          />
          <img
            alt="Line1636"
            src="/playground_assets/line1636-l5gh.svg"
            className="home-line23"
          />
          <img
            alt="Line1637"
            src="/playground_assets/line1637-fie9.svg"
            className="home-line24"
          />
          <img
            alt="Circle1638"
            src="/playground_assets/circle1638-jw1-200h.png"
            className="home-circle36"
          />
          <img
            alt="Circle1639"
            src="/playground_assets/circle1639-1wa7-200h.png"
            className="home-circle37"
          />
          <img
            alt="Circle1640"
            src="/playground_assets/circle1640-ik9-200h.png"
            className="home-circle38"
          />
          <img
            alt="Shape1641"
            src="/playground_assets/shape1641-qid.svg"
            className="home-shape250"
          />
          <img
            alt="Shape1642"
            src="/playground_assets/shape1642-ynhi.svg"
            className="home-shape251"
          />
          <img
            alt="Shape1643"
            src="/playground_assets/shape1643-gks.svg"
            className="home-shape252"
          />
          <img
            alt="Shape1644"
            src="/playground_assets/shape1644-tkst.svg"
            className="home-shape253"
          />
          <img
            alt="Shape1645"
            src="/playground_assets/shape1645-gxcm.svg"
            className="home-shape254"
          />
          <img
            alt="Shape1646"
            src="/playground_assets/shape1646-naql.svg"
            className="home-shape255"
          />
          <img
            alt="Shape1647"
            src="/playground_assets/shape1647-poei.svg"
            className="home-shape256"
          />
          <img
            alt="Shape1648"
            src="/playground_assets/shape1648-b7eg.svg"
            className="home-shape257"
          />
          <img
            alt="Shape1654"
            src="/playground_assets/shape1654-rny8.svg"
            className="home-shape258"
          />
          <img
            alt="Rectangle1655"
            src="/playground_assets/rectangle1655-seoq.svg"
            className="home-rectangle072"
          />
          <img
            alt="Rectangle1656"
            src="/playground_assets/rectangle1656-nmb.svg"
            className="home-rectangle073"
          />
          <img
            alt="Rectangle1657"
            src="/playground_assets/rectangle1657-epb.svg"
            className="home-rectangle074"
          />
          <img
            alt="Rectangle1658"
            src="/playground_assets/rectangle1658-23ka.svg"
            className="home-rectangle075"
          />
          <span className="home-text434">
            <span>Dr. Ibrahim Yekeni</span>
          </span>
          <span className="home-text436">
            <span>DOC 28 min ago</span>
          </span>
          <span className="home-text438">
            <span>ME 28 min ago</span>
          </span>
          <span className="home-text440">
            <span>
              <span>
                자연어 처리 관련 기업은 회사 A,
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <br></br>
              <span>회사 B, 회사 C 외 5개 회사가 있습니다.</span>
            </span>
          </span>
          <span className="home-text445">
            <span>자연어 처리 관련 기업 찾아줘</span>
          </span>
          <span className="home-text447">
            <span>Start typing here</span>
          </span>
          <span className="home-text449">
            <span>Active 50min ago</span>
          </span>
          <span className="home-text451">1</span>
          <span className="home-text452">2</span>
          <span className="home-text453">1</span>
          <span className="home-text454">
            <span>input text</span>
          </span>
          <span className="home-text456">X</span>
          <img
            alt="KakaoTalkPhoto2022120721342811671"
            src="/playground_assets/kakaotalkphoto2022120721342811671-pugr-200w.png"
            className="home-kakao-talk-photo2022120721342815"
          />
          <span className="home-text457">H</span>
          <span className="home-text458">O</span>
          <span className="home-text459">T</span>
          <span className="home-text460">S</span>
          <span className="home-text461">I</span>
          <span className="home-text462">H</span>
          <span className="home-text463">X</span>
          <img
            alt="Shape1679"
            src="/playground_assets/shape1679-02al.svg"
            className="home-shape259"
          />
          <img
            alt="Shape1683"
            src="/playground_assets/shape1683-s9k.svg"
            className="home-shape260"
          />
          <img
            alt="Shape1686"
            src="/playground_assets/shape1686-hv.svg"
            className="home-shape261"
          />
          <img
            alt="Shape1692"
            src="/playground_assets/shape1692-dk4u.svg"
            className="home-shape262"
          />
          <img
            alt="Shape1695"
            src="/playground_assets/shape1695-xzw.svg"
            className="home-shape263"
          />
          <img
            alt="Shape1698"
            src="/playground_assets/shape1698-frp.svg"
            className="home-shape264"
          />
          <img
            alt="Shape1702"
            src="/playground_assets/shape1702-ok1j.svg"
            className="home-shape265"
          />
          <img
            alt="Shape1705"
            src="/playground_assets/shape1705-tnr.svg"
            className="home-shape266"
          />
          <img
            alt="Rectangle1708"
            src="/playground_assets/rectangle1708-bphc.svg"
            className="home-rectangle076"
          />
          <img
            alt="Shape1709"
            src="/playground_assets/shape1709-la8.svg"
            className="home-shape267"
          />
          <span className="home-text464">
            <span>회사 B</span>
          </span>
          <span className="home-text466">
            <span>회사 C</span>
          </span>
        </div>
        <span className="home-text468">
          <span>
            <span>기술 키워드 : 자연어처리, 아동, 수학</span>
            <br></br>
            <span>
              회사 C는 자연어 처리 기술을 활용해 금융권의 비정형 데이터 자산화
              서비스를 제공하는 기업
            </span>
          </span>
        </span>
        <span className="home-text473">
          <span>
            <span>기술 키워드 : 자연어처리, 아동, 수학</span>
            <br></br>
            <span>
              회사 C는 자연어 처리 기술을 활용해 금융권의 비정형 데이터 자산화
              서비스를 제공하는 기업
            </span>
          </span>
        </span>
        <span className="home-text478">
          <span>
            <span>기술 키워드 : 자연어처리, 아동, 수학</span>
            <br></br>
            <span>
              회사 C는 자연어 처리 기술을 활용해 금융권의 비정형 데이터 자산화
              서비스를 제공하는 기업
            </span>
          </span>
        </span>
        <span className="home-text483">
          <span>
            <span>기술 키워드 : 자연어처리, 아동, 수학</span>
            <br></br>
            <span>
              회사 C는 자연어 처리 기술을 활용해 금융권의 비정형 데이터 자산화
              서비스를 제공하는 기업
            </span>
          </span>
        </span>
        <span className="home-text488">
          <span>
            <span>기술 키워드 : 자연어처리, 아동, 수학</span>
            <br></br>
            <span>
              회사 C는 자연어 처리 기술을 활용해 금융권의 비정형 데이터 자산화
              서비스를 제공하는 기업
            </span>
          </span>
        </span>
        <span className="home-text493">
          <span>기술 키워드 : 자연어 처리, 인공지능, 교육, 아동</span>
        </span>
        <span className="home-text495">
          <span>회사 A</span>
        </span>
      </div>
      <div className="home-desktop12">
        <span className="home-text497">O</span>
        <span className="home-text498">T</span>
        <span className="home-text499">S</span>
        <span className="home-text500">I</span>
        <span className="home-text501">H</span>
        <img
          alt="Shape1330"
          src="/playground_assets/shape1330-y54.svg"
          className="home-shape268"
        />
        <img
          alt="Line1334"
          src="/playground_assets/line1334-sb9.svg"
          className="home-line25"
        />
        <img
          alt="Shape1335"
          src="/playground_assets/shape1335-vzkr.svg"
          className="home-shape269"
        />
        <img
          alt="Rectangle1336"
          src="/playground_assets/rectangle1336-jz7-200h.png"
          className="home-rectangle077"
        />
        <span className="home-text502">
          <span>Overview</span>
        </span>
        <img
          alt="Line1338"
          src="/playground_assets/line1338-8vs.svg"
          className="home-line26"
        />
        <img
          alt="Line1339"
          src="/playground_assets/line1339-w7hw.svg"
          className="home-line27"
        />
        <span className="home-text504">
          <span>TODAY</span>
        </span>
        <img
          alt="Shape1341"
          src="/playground_assets/shape1341-w3a9.svg"
          className="home-shape270"
        />
        <img
          alt="Shape1342"
          src="/playground_assets/shape1342-6nca.svg"
          className="home-shape271"
        />
        <span className="home-text506">
          <span>
            연매출 7억 이상 자연어처리 관련 기업은 회사 C, 회사 D, 회사 E가
            있습니다.
          </span>
        </span>
        <span className="home-text508">
          <span>DOC 28 min ago</span>
        </span>
        <span className="home-text510">
          <span>DOC 28 min ago</span>
        </span>
        <img
          alt="Circle1346"
          src="/playground_assets/circle1346-cp9-200h.png"
          className="home-circle39"
        />
        <img
          alt="Circle1347"
          src="/playground_assets/circle1347-t4ci-200h.png"
          className="home-circle40"
        />
        <span className="home-text512">
          <span>그 중에서 연매출 7억 이상 기업만 보여줘</span>
        </span>
        <img
          alt="Rectangle191349"
          src="/playground_assets/rectangle191349-lmml-200h.png"
          className="home-rectangle191"
        />
        <img
          alt="Rectangle211350"
          src="/playground_assets/rectangle211350-tcii-600h.png"
          className="home-rectangle211"
        />
        <img
          alt="Rectangle281351"
          src="/playground_assets/rectangle281351-tjgb.svg"
          className="home-rectangle281"
        />
        <img
          alt="Rectangle291352"
          src="/playground_assets/rectangle291352-afxt.svg"
          className="home-rectangle29"
        />
        <span className="home-text514">
          <span>긍정</span>
        </span>
        <img
          alt="Rectangle1354"
          src="/playground_assets/rectangle1354-sw1u.svg"
          className="home-rectangle078"
        />
        <span className="home-text516">
          <span>회사 A</span>
        </span>
        <img
          alt="Line1356"
          src="/playground_assets/line1356-i09a.svg"
          className="home-line28"
        />
        <img
          alt="Rectangle261357"
          src="/playground_assets/rectangle261357-q7r.svg"
          className="home-rectangle261"
        />
        <img
          alt="Rectangle271358"
          src="/playground_assets/rectangle271358-pyhq.svg"
          className="home-rectangle271"
        />
        <span className="home-text518">
          <span>중립</span>
        </span>
        <img
          alt="Rectangle301360"
          src="/playground_assets/rectangle301360-m57.svg"
          className="home-rectangle30"
        />
        <img
          alt="Rectangle311361"
          src="/playground_assets/rectangle311361-3gm.svg"
          className="home-rectangle31"
        />
        <span className="home-text520">
          <span>긍정</span>
        </span>
        <div className="home-patient-dashboard-chats-light-theme3">
          <img
            alt="Rectangle1364"
            src="/playground_assets/rectangle1364-aywe.svg"
            className="home-rectangle079"
          />
          <div className="home-group17">
            <img
              alt="Rectangle1366"
              src="/playground_assets/rectangle1366-qhff.svg"
              className="home-rectangle080"
            />
          </div>
          <img
            alt="Shape1367"
            src="/playground_assets/shape1367-4joh.svg"
            className="home-shape272"
          />
          <img
            alt="Shape1368"
            src="/playground_assets/shape1368-2xxf.svg"
            className="home-shape273"
          />
          <img
            alt="Shape1369"
            src="/playground_assets/shape1369-oxpt.svg"
            className="home-shape274"
          />
          <img
            alt="Shape1370"
            src="/playground_assets/shape1370-gtin.svg"
            className="home-shape275"
          />
          <img
            alt="Shape1371"
            src="/playground_assets/shape1371-7z.svg"
            className="home-shape276"
          />
          <img
            alt="Shape1372"
            src="/playground_assets/shape1372-n7z.svg"
            className="home-shape277"
          />
          <img
            alt="Shape1373"
            src="/playground_assets/shape1373-b3oh.svg"
            className="home-shape278"
          />
          <img
            alt="Shape1374"
            src="/playground_assets/shape1374-a8xu.svg"
            className="home-shape279"
          />
          <img
            alt="Shape1375"
            src="/playground_assets/shape1375-yre95.svg"
            className="home-shape280"
          />
          <img
            alt="Shape1376"
            src="/playground_assets/shape1376-qdqs.svg"
            className="home-shape281"
          />
          <img
            alt="Shape1377"
            src="/playground_assets/shape1377-b4h.svg"
            className="home-shape282"
          />
          <img
            alt="Shape1378"
            src="/playground_assets/shape1378-aqcn.svg"
            className="home-shape283"
          />
          <img
            alt="Line1379"
            src="/playground_assets/line1379-2eyu.svg"
            className="home-line29"
          />
          <img
            alt="Circle1380"
            src="/playground_assets/circle1380-77g-200h.png"
            className="home-circle41"
          />
          <img
            alt="Circle1381"
            src="/playground_assets/circle1381-0clk-200h.png"
            className="home-circle42"
          />
          <div className="home-group43">
            <img
              alt="Shape1383"
              src="/playground_assets/shape1383-3m22.svg"
              className="home-shape284"
            />
            <img
              alt="Shape1384"
              src="/playground_assets/shape1384-ga5.svg"
              className="home-shape285"
            />
          </div>
          <img
            alt="Circle1385"
            src="/playground_assets/circle1385-3v52-200h.png"
            className="home-circle43"
          />
          <div className="home-notification-bell3">
            <img
              alt="Shape1387"
              src="/playground_assets/shape1387-9kkl.svg"
              className="home-shape286"
            />
            <img
              alt="Shape1388"
              src="/playground_assets/shape1388-11d.svg"
              className="home-shape287"
            />
            <img
              alt="Shape1389"
              src="/playground_assets/shape1389-xiqs.svg"
              className="home-shape288"
            />
          </div>
          <img
            alt="Line1392"
            src="/playground_assets/line1392-m3.svg"
            className="home-line30"
          />
          <img
            alt="Line1393"
            src="/playground_assets/line1393-3r7q.svg"
            className="home-line31"
          />
          <img
            alt="Rectangle1394"
            src="/playground_assets/rectangle1394-s9v6.svg"
            className="home-rectangle081"
          />
          <img
            alt="Shape1395"
            src="/playground_assets/shape1395-zl.svg"
            className="home-shape289"
          />
          <img
            alt="Shape1398"
            src="/playground_assets/shape1398-rcls.svg"
            className="home-shape290"
          />
          <img
            alt="Shape1399"
            src="/playground_assets/shape1399-ie3n.svg"
            className="home-shape291"
          />
          <img
            alt="Shape1400"
            src="/playground_assets/shape1400-gvf38.svg"
            className="home-shape292"
          />
          <div>
            <img
              alt="Shape1402"
              src="/playground_assets/shape1402-iln.svg"
              className="home-shape293"
            />
            <img
              alt="Shape1403"
              src="/playground_assets/shape1403-qap.svg"
              className="home-shape294"
            />
            <img
              alt="Shape1404"
              src="/playground_assets/shape1404-x4wd.svg"
              className="home-shape295"
            />
            <img
              alt="Shape1405"
              src="/playground_assets/shape1405-p2h6.svg"
              className="home-shape296"
            />
            <img
              alt="Shape1406"
              src="/playground_assets/shape1406-nytr.svg"
              className="home-shape297"
            />
          </div>
          <img
            alt="Shape1407"
            src="/playground_assets/shape1407-oupp.svg"
            className="home-shape298"
          />
          <img
            alt="Shape1413"
            src="/playground_assets/shape1413-bdyl.svg"
            className="home-shape299"
          />
          <span className="home-text522">
            <span>Chats</span>
          </span>
          <span className="home-text524">
            <span>Apply Dark Theme</span>
          </span>
          <span className="home-text526">
            <span>Ola Boluwatife</span>
          </span>
          <span className="home-text528">
            <span>Samsung electronics</span>
          </span>
          <span className="home-text530">
            <span>Search pathology results</span>
          </span>
          <span className="home-text532">
            <span>Chats</span>
          </span>
          <span className="home-text534">
            <span>Settings</span>
          </span>
          <span className="home-text536">
            <span>+234 92 928 2891 +234 60 621 2098</span>
          </span>
          <span className="home-text538">
            <span>Logouts</span>
          </span>
          <span className="home-text540">
            <span>Emergency Hotlines:</span>
          </span>
          <span className="home-text542">
            <span>ACCOUNT</span>
          </span>
          <img
            alt="Shape1427"
            src="/playground_assets/shape1427-653.svg"
            className="home-shape300"
          />
          <div className="home-group73">
            <img
              alt="Shape1429"
              src="/playground_assets/shape1429-ogh4.svg"
              className="home-shape301"
            />
            <img
              alt="Shape1430"
              src="/playground_assets/shape1430-ejrg.svg"
              className="home-shape302"
            />
          </div>
          <img
            alt="Shape1431"
            src="/playground_assets/shape1431-d1h.svg"
            className="home-shape303"
          />
          <img
            alt="Line1432"
            src="/playground_assets/line1432-eyfo.svg"
            className="home-line32"
          />
          <img
            alt="Line1433"
            src="/playground_assets/line1433-p9nf.svg"
            className="home-line33"
          />
          <img
            alt="Line1434"
            src="/playground_assets/line1434-rxum.svg"
            className="home-line34"
          />
          <img
            alt="Circle1435"
            src="/playground_assets/circle1435-esia-200h.png"
            className="home-circle44"
          />
          <img
            alt="Circle1436"
            src="/playground_assets/circle1436-s6l-200h.png"
            className="home-circle45"
          />
          <img
            alt="Circle1437"
            src="/playground_assets/circle1437-e9b9-200h.png"
            className="home-circle46"
          />
          <img
            alt="Shape1438"
            src="/playground_assets/shape1438-5pha.svg"
            className="home-shape304"
          />
          <img
            alt="Shape1439"
            src="/playground_assets/shape1439-t4zg.svg"
            className="home-shape305"
          />
          <img
            alt="Shape1440"
            src="/playground_assets/shape1440-3qwm.svg"
            className="home-shape306"
          />
          <img
            alt="Shape1441"
            src="/playground_assets/shape1441-oymp.svg"
            className="home-shape307"
          />
          <img
            alt="Shape1442"
            src="/playground_assets/shape1442-tfve.svg"
            className="home-shape308"
          />
          <img
            alt="Shape1443"
            src="/playground_assets/shape1443-1wd8.svg"
            className="home-shape309"
          />
          <img
            alt="Shape1444"
            src="/playground_assets/shape1444-a5a.svg"
            className="home-shape310"
          />
          <img
            alt="Shape1445"
            src="/playground_assets/shape1445-yyvt.svg"
            className="home-shape311"
          />
          <img
            alt="Shape1451"
            src="/playground_assets/shape1451-t57m.svg"
            className="home-shape312"
          />
          <img
            alt="Rectangle1452"
            src="/playground_assets/rectangle1452-7ngs.svg"
            className="home-rectangle082"
          />
          <img
            alt="Rectangle1453"
            src="/playground_assets/rectangle1453-21rk.svg"
            className="home-rectangle083"
          />
          <img
            alt="Rectangle1454"
            src="/playground_assets/rectangle1454-vicc.svg"
            className="home-rectangle084"
          />
          <img
            alt="Rectangle1455"
            src="/playground_assets/rectangle1455-yhqc.svg"
            className="home-rectangle085"
          />
          <span className="home-text544">
            <span>Dr. Ibrahim Yekeni</span>
          </span>
          <span className="home-text546">
            <span>DOC 28 min ago</span>
          </span>
          <span className="home-text548">
            <span>ME 28 min ago</span>
          </span>
          <span className="home-text550">
            <span>
              <span>
                자연어 처리 관련 기업은 회사 A,
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <br></br>
              <span>회사 B, 회사 C 외 5개 회사가 있습니다.</span>
            </span>
          </span>
          <span className="home-text555">
            <span>자연어 처리 관련 기업 찾아줘</span>
          </span>
          <span className="home-text557">
            <span>Start typing here</span>
          </span>
          <span className="home-text559">
            <span>Active 50min ago</span>
          </span>
          <span className="home-text561">1</span>
          <span className="home-text562">2</span>
          <span className="home-text563">1</span>
          <span className="home-text564">
            <span>input text</span>
          </span>
          <span className="home-text566">X</span>
          <img
            alt="KakaoTalkPhoto2022120721342811468"
            src="/playground_assets/kakaotalkphoto2022120721342811468-ain-200w.png"
            className="home-kakao-talk-photo2022120721342816"
          />
          <span className="home-text567">H</span>
          <span className="home-text568">O</span>
          <span className="home-text569">T</span>
          <span className="home-text570">S</span>
          <span className="home-text571">I</span>
          <span className="home-text572">H</span>
          <span className="home-text573">X</span>
          <img
            alt="Shape1476"
            src="/playground_assets/shape1476-fotw.svg"
            className="home-shape313"
          />
          <img
            alt="Shape1480"
            src="/playground_assets/shape1480-jqj.svg"
            className="home-shape314"
          />
          <img
            alt="Shape1483"
            src="/playground_assets/shape1483-nens.svg"
            className="home-shape315"
          />
          <img
            alt="Shape1489"
            src="/playground_assets/shape1489-vex9.svg"
            className="home-shape316"
          />
          <img
            alt="Shape1492"
            src="/playground_assets/shape1492-9ipw.svg"
            className="home-shape317"
          />
          <img
            alt="Shape1495"
            src="/playground_assets/shape1495-j848.svg"
            className="home-shape318"
          />
          <img
            alt="Shape1499"
            src="/playground_assets/shape1499-g4j.svg"
            className="home-shape319"
          />
          <img
            alt="Shape1502"
            src="/playground_assets/shape1502-mgkc.svg"
            className="home-shape320"
          />
          <img
            alt="Rectangle1505"
            src="/playground_assets/rectangle1505-hvvb.svg"
            className="home-rectangle086"
          />
          <img
            alt="Shape1506"
            src="/playground_assets/shape1506-2tt.svg"
            className="home-shape321"
          />
          <span className="home-text574">
            <span>회사 B</span>
          </span>
          <span className="home-text576">
            <span>회사 C</span>
          </span>
        </div>
        <span className="home-text578">
          <span>
            <span>기사 제목, 날짜</span>
            <br></br>
            <span></span>
            <br></br>
            <span>
              이 회사가 개발한 컴퓨터 비전용 고성능 AI 반도체 ‘워보이’가 2021년
              글로벌 AI 반도체 성능 경영대회 ‘엠엘퍼프(MLPerf)’ 추론 분야에서
              미국 엔비디아의 ‘T4’를 꺾으며 주목받았다.
            </span>
            <br></br>
            <span> 출처 : YTN</span>
          </span>
        </span>
        <span className="home-text587">
          <span>
            <span>기사 제목, 날짜</span>
            <br></br>
            <span></span>
            <br></br>
            <span>
              이 회사가 개발한 컴퓨터 비전용 고성능 AI 반도체 ‘워보이’가 2021년
              글로벌 AI 반도체 성능 경영대회 ‘엠엘퍼프(MLPerf)’ 추론 분야에서
              미국 엔비디아의 ‘T4’를 꺾으며 주목받았다.
            </span>
            <br></br>
            <span> 출처 : JTBC</span>
          </span>
        </span>
        <span className="home-text596">
          <span>
            <span>기사 제목, 날짜</span>
            <br></br>
            <span></span>
            <br></br>
            <span>
              텐 (대표 오세진)은 총 30억 원 규모의 프리시리즈 A 투자를
              유치했다고 9일 밝혔다. 이번 투자는 어센도벤처스, 퀸텀벤처스코리아,
              신한 캐피탈, 신용보증기금이 참여하였다.
            </span>
            <br></br>
            <span> 출처 : SBS Biz</span>
          </span>
        </span>
        <span className="home-text605">
          <span>기술 키워드 : 자연어 처리, 인공지능, 교육, 아동</span>
        </span>
        <span className="home-text607">
          <span>회사 A</span>
        </span>
      </div>
      <div className="home-desktop14">
        <span className="home-text609">O</span>
        <span className="home-text610">T</span>
        <span className="home-text611">S</span>
        <span className="home-text612">I</span>
        <span className="home-text613">H</span>
        <img
          alt="Shape118"
          src="/playground_assets/shape118-sz9.svg"
          className="home-shape322"
        />
        <img
          alt="Line122"
          src="/playground_assets/line122-qagj.svg"
          className="home-line35"
        />
        <img
          alt="Shape123"
          src="/playground_assets/shape123-hhk8.svg"
          className="home-shape323"
        />
        <img
          alt="Rectangle124"
          src="/playground_assets/rectangle124-b2pb-200h.png"
          className="home-rectangle087"
        />
        <span className="home-text614">
          <span>Overview</span>
        </span>
        <img
          alt="Line126"
          src="/playground_assets/line126-9zfw.svg"
          className="home-line36"
        />
        <img
          alt="Line127"
          src="/playground_assets/line127-o26k.svg"
          className="home-line37"
        />
        <span className="home-text616">
          <span>TODAY</span>
        </span>
        <img
          alt="Shape129"
          src="/playground_assets/shape129-0if7.svg"
          className="home-shape324"
        />
        <span className="home-text618">
          <span>회사 A의 최근 재무제표 알려줘</span>
        </span>
        <span className="home-text620">
          <span>DOC 28 min ago</span>
        </span>
        <span className="home-text622">
          <span>DOC 28 min ago</span>
        </span>
        <img
          alt="Circle133"
          src="/playground_assets/circle133-h9ko-200h.png"
          className="home-circle47"
        />
        <img
          alt="Circle134"
          src="/playground_assets/circle134-mfab5-200h.png"
          className="home-circle48"
        />
        <img
          alt="Shape135"
          src="/playground_assets/shape135-tcbk.svg"
          className="home-shape325"
        />
        <img
          alt="Shape136"
          src="/playground_assets/shape136-gfv4.svg"
          className="home-shape326"
        />
        <img
          alt="Shape137"
          src="/playground_assets/shape137-8b18.svg"
          className="home-shape327"
        />
        <div className="home-group6">
          <img
            alt="Shape148"
            src="/playground_assets/shape148-aneh.svg"
            className="home-shape328"
          />
          <img
            alt="Shape149"
            src="/playground_assets/shape149-t11q.svg"
            className="home-shape329"
          />
          <img
            alt="Shape150"
            src="/playground_assets/shape150-v13q.svg"
            className="home-shape330"
          />
        </div>
        <div className="home-group5">
          <img
            alt="Shape156"
            src="/playground_assets/shape156-ajdg.svg"
            className="home-shape331"
          />
          <img
            alt="Shape157"
            src="/playground_assets/shape157-mx3.svg"
            className="home-shape332"
          />
        </div>
        <span className="home-text624">
          <span>Financial Statements.pdf</span>
        </span>
        <img
          alt="Rectangle159"
          src="/playground_assets/rectangle159-ar9d.svg"
          className="home-rectangle088"
        />
        <img
          alt="Rectangle19160"
          src="/playground_assets/rectangle19160-iz7f-200h.png"
          className="home-rectangle192"
        />
        <img
          alt="Rectangle21161"
          src="/playground_assets/rectangle21161-z6jq-600h.png"
          className="home-rectangle212"
        />
        <span className="home-text626">
          <span>
            <span>
              회사 A 의 Price volatility는 __, Consumer credit는 __, STWF는 __,
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
            <br></br>
            <span>Business credit는 __, Home mortgages는 __ 입니다.</span>
            <br></br>
            <span></span>
          </span>
        </span>
        <img
          alt="Rectangle23163"
          src="/playground_assets/rectangle23163-qae-400h.png"
          className="home-rectangle23"
        />
        <img
          alt="Rectangle22164"
          src="/playground_assets/rectangle22164-qn7g-400w.png"
          className="home-rectangle221"
        />
        <img
          alt="Rectangle165"
          src="/playground_assets/rectangle165-ke8-200w.png"
          className="home-rectangle089"
        />
        <img
          alt="Rectangle166"
          src="/playground_assets/rectangle166-kj5h-200w.png"
          className="home-rectangle090"
        />
        <img
          alt="Rectangle167"
          src="/playground_assets/rectangle167-joea-200w.png"
          className="home-rectangle091"
        />
        <img
          alt="Rectangle168"
          src="/playground_assets/rectangle168-91wo-200w.png"
          className="home-rectangle092"
        />
        <img
          alt="Circle169"
          src="/playground_assets/circle169-v4ks-200h.png"
          className="home-circle49"
        />
        <img
          alt="Circle170"
          src="/playground_assets/circle170-zk7c-200h.png"
          className="home-circle50"
        />
        <img
          alt="Circle171"
          src="/playground_assets/circle171-g9bt-200h.png"
          className="home-circle51"
        />
        <img
          alt="Circle172"
          src="/playground_assets/circle172-74ze-200h.png"
          className="home-circle52"
        />
        <img
          alt="Circle173"
          src="/playground_assets/circle173-a9f-200h.png"
          className="home-circle53"
        />
        <img
          alt="Circle174"
          src="/playground_assets/circle174-ddxa-200h.png"
          className="home-circle54"
        />
        <img
          alt="Circle175"
          src="/playground_assets/circle175-ytzh-200h.png"
          className="home-circle55"
        />
        <span className="home-text633">
          <span>June</span>
        </span>
        <span className="home-text635">
          <span>July</span>
        </span>
        <span className="home-text637">
          <span>April</span>
        </span>
        <span className="home-text639">
          <span>May</span>
        </span>
        <span className="home-text641">
          <span>Aug</span>
        </span>
        <span className="home-text643">
          <span>Sept</span>
        </span>
        <span className="home-text645">
          <span>Oct</span>
        </span>
        <span className="home-text647">
          <span>Nov</span>
        </span>
        <span className="home-text649">
          <span>Dec</span>
        </span>
        <img
          alt="Rectangle185"
          src="/playground_assets/rectangle185-41b.svg"
          className="home-rectangle093"
        />
        <img
          alt="Rectangle186"
          src="/playground_assets/rectangle186-d57k-200w.png"
          className="home-rectangle094"
        />
        <img
          alt="Rectangle187"
          src="/playground_assets/rectangle187-xllq.svg"
          className="home-rectangle095"
        />
        <img
          alt="Rectangle188"
          src="/playground_assets/rectangle188-absa-200w.png"
          className="home-rectangle096"
        />
        <img
          alt="Rectangle189"
          src="/playground_assets/rectangle189-2cj.svg"
          className="home-rectangle097"
        />
        <img
          alt="Rectangle190"
          src="/playground_assets/rectangle190-l5wn5-200w.png"
          className="home-rectangle098"
        />
        <img
          alt="Rectangle191"
          src="/playground_assets/rectangle191-iha-200w.png"
          className="home-rectangle099"
        />
        <img
          alt="Rectangle192"
          src="/playground_assets/rectangle192-2yxq-200w.png"
          className="home-rectangle100"
        />
        <img
          alt="Rectangle193"
          src="/playground_assets/rectangle193-r4hb-200h.png"
          className="home-rectangle101"
        />
        <img
          alt="Rectangle194"
          src="/playground_assets/rectangle194-nucr-200w.png"
          className="home-rectangle102"
        />
        <img
          alt="Rectangle195"
          src="/playground_assets/rectangle195-59d.svg"
          className="home-rectangle103"
        />
        <img
          alt="Rectangle196"
          src="/playground_assets/rectangle196-y747-200w.png"
          className="home-rectangle104"
        />
        <img
          alt="Rectangle197"
          src="/playground_assets/rectangle197-rwyj-200w.png"
          className="home-rectangle105"
        />
        <img
          alt="Rectangle198"
          src="/playground_assets/rectangle198-xmnp-200w.png"
          className="home-rectangle106"
        />
        <img
          alt="Rectangle199"
          src="/playground_assets/rectangle199-v2it.svg"
          className="home-rectangle107"
        />
        <img
          alt="Rectangle1100"
          src="/playground_assets/rectangle1100-edpg-200w.png"
          className="home-rectangle108"
        />
        <img
          alt="Rectangle1101"
          src="/playground_assets/rectangle1101-d9cf-200w.png"
          className="home-rectangle109"
        />
        <img
          alt="Rectangle1102"
          src="/playground_assets/rectangle1102-cp6u-200w.png"
          className="home-rectangle110"
        />
        <img
          alt="Rectangle1103"
          src="/playground_assets/rectangle1103-nz18.svg"
          className="home-rectangle111"
        />
        <img
          alt="Rectangle1104"
          src="/playground_assets/rectangle1104-y539.svg"
          className="home-rectangle112"
        />
        <img
          alt="Rectangle1105"
          src="/playground_assets/rectangle1105-27kr-200w.png"
          className="home-rectangle113"
        />
        <img
          alt="Rectangle1106"
          src="/playground_assets/rectangle1106-5ta-200w.png"
          className="home-rectangle114"
        />
        <img
          alt="Rectangle1107"
          src="/playground_assets/rectangle1107-zns3-200w.png"
          className="home-rectangle115"
        />
        <img
          alt="Rectangle1108"
          src="/playground_assets/rectangle1108-qd9.svg"
          className="home-rectangle116"
        />
        <img
          alt="Rectangle1109"
          src="/playground_assets/rectangle1109-urqk.svg"
          className="home-rectangle117"
        />
        <img
          alt="Rectangle1110"
          src="/playground_assets/rectangle1110-zx47-200w.png"
          className="home-rectangle118"
        />
        <img
          alt="Rectangle1111"
          src="/playground_assets/rectangle1111-irmt-200w.png"
          className="home-rectangle119"
        />
        <img
          alt="Rectangle1112"
          src="/playground_assets/rectangle1112-z9ut.svg"
          className="home-rectangle120"
        />
        <img
          alt="Rectangle1113"
          src="/playground_assets/rectangle1113-aba.svg"
          className="home-rectangle121"
        />
        <img
          alt="Rectangle1114"
          src="/playground_assets/rectangle1114-clf5-200w.png"
          className="home-rectangle122"
        />
        <img
          alt="Rectangle1115"
          src="/playground_assets/rectangle1115-yg5-200w.png"
          className="home-rectangle123"
        />
        <img
          alt="Rectangle1116"
          src="/playground_assets/rectangle1116-97da-200w.png"
          className="home-rectangle124"
        />
        <img
          alt="Rectangle1117"
          src="/playground_assets/rectangle1117-9tbv-200w.png"
          className="home-rectangle125"
        />
        <img
          alt="Rectangle1118"
          src="/playground_assets/rectangle1118-87xp-200w.png"
          className="home-rectangle126"
        />
        <img
          alt="Rectangle1119"
          src="/playground_assets/rectangle1119-2l1o-200w.png"
          className="home-rectangle127"
        />
        <img
          alt="Rectangle1120"
          src="/playground_assets/rectangle1120-yv45-200w.png"
          className="home-rectangle128"
        />
        <img
          alt="Rectangle1121"
          src="/playground_assets/rectangle1121-esjd.svg"
          className="home-rectangle129"
        />
        <span className="home-text651">
          <span>회사 A</span>
        </span>
        <span className="home-text653">
          <span>Price volatility</span>
        </span>
        <span className="home-text655">
          <span>Consumer credit</span>
        </span>
        <span className="home-text657">
          <span>STWF</span>
        </span>
        <span className="home-text659">
          <span>Home mortgages</span>
        </span>
        <span className="home-text661">
          <span>Business credit</span>
        </span>
        <img
          alt="Circle1128"
          src="/playground_assets/circle1128-y3t3-200h.png"
          className="home-circle56"
        />
        <img
          alt="Circle1129"
          src="/playground_assets/circle1129-f373-200h.png"
          className="home-circle57"
        />
        <img
          alt="Circle1130"
          src="/playground_assets/circle1130-ux7l-200h.png"
          className="home-circle58"
        />
        <img
          alt="Circle1131"
          src="/playground_assets/circle1131-qnfd-200h.png"
          className="home-circle59"
        />
        <img
          alt="Circle1132"
          src="/playground_assets/circle1132-m7rm-200w.png"
          className="home-circle60"
        />
        <img
          alt="Circle1133"
          src="/playground_assets/circle1133-tym-200h.png"
          className="home-circle61"
        />
        <img
          alt="Circle1134"
          src="/playground_assets/circle1134-evx-200w.png"
          className="home-circle62"
        />
        <img
          alt="Circle1135"
          src="/playground_assets/circle1135-4deh-200h.png"
          className="home-circle63"
        />
        <div className="home-group18">
          <img
            alt="Shape1137"
            src="/playground_assets/shape1137-xynm.svg"
            className="home-shape333"
          />
          <img
            alt="Shape1138"
            src="/playground_assets/shape1138-2ky.svg"
            className="home-shape334"
          />
          <div className="home-group9">
            <div className="home-group19">
              <img
                alt="Shape1141"
                src="/playground_assets/shape1141-5tio.svg"
                className="home-shape335"
              />
            </div>
            <div className="home-group20">
              <img
                alt="Shape1143"
                src="/playground_assets/shape1143-2y8.svg"
                className="home-shape336"
              />
            </div>
            <div className="home-group21 home-group21">
              <img
                alt="Shape1145"
                src="/playground_assets/shape1145-b3qhy.svg"
                className="home-shape337"
              />
            </div>
            <div className="home-group22 home-group22">
              <img
                alt="Shape1147"
                src="/playground_assets/shape1147-m4ip.svg"
                className="home-shape338"
              />
            </div>
          </div>
        </div>
        <img
          alt="Circle1148"
          src="/playground_assets/circle1148-matb-200h.png"
          className="home-circle64"
        />
        <img
          alt="Circle1149"
          src="/playground_assets/circle1149-a95rn-200h.png"
          className="home-circle65"
        />
        <img
          alt="Circle1150"
          src="/playground_assets/circle1150-21rj-200h.png"
          className="home-circle66"
        />
        <span className="home-text663">
          <span>Systemic Vulnerability</span>
        </span>
        <img
          alt="Rectangle241152"
          src="/playground_assets/rectangle241152-tik8.svg"
          className="home-rectangle241"
        />
        <span className="home-text665">
          <span>June</span>
        </span>
        <span className="home-text667">
          <span>July</span>
        </span>
        <span className="home-text669">
          <span>Aug</span>
        </span>
        <span className="home-text671">
          <span>Sept</span>
        </span>
        <span className="home-text673">
          <span>Oct</span>
        </span>
        <span className="home-text675">
          <span>Nov</span>
        </span>
        <span className="home-text677">
          <span>Dec</span>
        </span>
        <span className="home-text679">
          <span>June</span>
        </span>
        <span className="home-text681">
          <span>July</span>
        </span>
        <span className="home-text683">
          <span>Aug</span>
        </span>
        <span className="home-text685">
          <span>Sept</span>
        </span>
        <span className="home-text687">
          <span>Oct</span>
        </span>
        <span className="home-text689">
          <span>Nov</span>
        </span>
        <span className="home-text691">
          <span>Dec</span>
        </span>
        <span className="home-text693">
          <span>June</span>
        </span>
        <span className="home-text695">
          <span>July</span>
        </span>
        <span className="home-text697">
          <span>Aug</span>
        </span>
        <span className="home-text699">
          <span>Sept</span>
        </span>
        <span className="home-text701">
          <span>Oct</span>
        </span>
        <span className="home-text703">
          <span>Nov</span>
        </span>
        <span className="home-text705">
          <span>Dec</span>
        </span>
        <div className="home-patient-dashboard-chats-light-theme4">
          <img
            alt="Rectangle1175"
            src="/playground_assets/rectangle1175-2fta9.svg"
            className="home-rectangle130"
          />
          <div className="home-group23 home-group23">
            <img
              alt="Rectangle1177"
              src="/playground_assets/rectangle1177-nzp8.svg"
              className="home-rectangle131"
            />
          </div>
          <img
            alt="Shape1178"
            src="/playground_assets/shape1178-otp.svg"
            className="home-shape339"
          />
          <img
            alt="Shape1179"
            src="/playground_assets/shape1179-3o.svg"
            className="home-shape340"
          />
          <img
            alt="Shape1180"
            src="/playground_assets/shape1180-89d9.svg"
            className="home-shape341"
          />
          <img
            alt="Shape1181"
            src="/playground_assets/shape1181-onx.svg"
            className="home-shape342"
          />
          <img
            alt="Shape1182"
            src="/playground_assets/shape1182-tn7.svg"
            className="home-shape343"
          />
          <img
            alt="Shape1183"
            src="/playground_assets/shape1183-sng.svg"
            className="home-shape344"
          />
          <img
            alt="Shape1184"
            src="/playground_assets/shape1184-2rmk.svg"
            className="home-shape345"
          />
          <img
            alt="Shape1185"
            src="/playground_assets/shape1185-f8d.svg"
            className="home-shape346"
          />
          <img
            alt="Shape1186"
            src="/playground_assets/shape1186-9bxa.svg"
            className="home-shape347"
          />
          <img
            alt="Shape1187"
            src="/playground_assets/shape1187-rob.svg"
            className="home-shape348"
          />
          <img
            alt="Shape1188"
            src="/playground_assets/shape1188-pl6v.svg"
            className="home-shape349"
          />
          <img
            alt="Shape1189"
            src="/playground_assets/shape1189-o5ul.svg"
            className="home-shape350"
          />
          <img
            alt="Line1190"
            src="/playground_assets/line1190-3iaq.svg"
            className="home-line38"
          />
          <img
            alt="Circle1191"
            src="/playground_assets/circle1191-ty9-200h.png"
            className="home-circle67"
          />
          <img
            alt="Circle1192"
            src="/playground_assets/circle1192-cnid-200h.png"
            className="home-circle68"
          />
          <div className="home-group44">
            <img
              alt="Shape1194"
              src="/playground_assets/shape1194-2n5c.svg"
              className="home-shape351"
            />
            <img
              alt="Shape1195"
              src="/playground_assets/shape1195-d2p.svg"
              className="home-shape352"
            />
          </div>
          <img
            alt="Circle1196"
            src="/playground_assets/circle1196-2jbi-200h.png"
            className="home-circle69"
          />
          <div className="home-notification-bell4">
            <img
              alt="Shape1198"
              src="/playground_assets/shape1198-lnth.svg"
              className="home-shape353"
            />
            <img
              alt="Shape1199"
              src="/playground_assets/shape1199-fwm.svg"
              className="home-shape354"
            />
            <img
              alt="Shape1200"
              src="/playground_assets/shape1200-w2r.svg"
              className="home-shape355"
            />
          </div>
          <img
            alt="Line1203"
            src="/playground_assets/line1203-zqik.svg"
            className="home-line39"
          />
          <img
            alt="Line1204"
            src="/playground_assets/line1204-3fa.svg"
            className="home-line40"
          />
          <img
            alt="Rectangle1205"
            src="/playground_assets/rectangle1205-cyf.svg"
            className="home-rectangle132"
          />
          <img
            alt="Shape1206"
            src="/playground_assets/shape1206-wvba.svg"
            className="home-shape356"
          />
          <img
            alt="Shape1209"
            src="/playground_assets/shape1209-9o8.svg"
            className="home-shape357"
          />
          <img
            alt="Shape1210"
            src="/playground_assets/shape1210-lb1a.svg"
            className="home-shape358"
          />
          <img
            alt="Shape1211"
            src="/playground_assets/shape1211-66hj.svg"
            className="home-shape359"
          />
          <div className="home-group24">
            <img
              alt="Shape1213"
              src="/playground_assets/shape1213-gaft.svg"
              className="home-shape360"
            />
            <img
              alt="Shape1214"
              src="/playground_assets/shape1214-x35i.svg"
              className="home-shape361"
            />
            <img
              alt="Shape1215"
              src="/playground_assets/shape1215-j2p8.svg"
              className="home-shape362"
            />
            <img
              alt="Shape1216"
              src="/playground_assets/shape1216-saa.svg"
              className="home-shape363"
            />
            <img
              alt="Shape1217"
              src="/playground_assets/shape1217-fykr.svg"
              className="home-shape364"
            />
          </div>
          <img
            alt="Shape1218"
            src="/playground_assets/shape1218-my5q.svg"
            className="home-shape365"
          />
          <img
            alt="Shape1224"
            src="/playground_assets/shape1224-241o.svg"
            className="home-shape366"
          />
          <span className="home-text707">
            <span>Chats</span>
          </span>
          <span className="home-text709">
            <span>Apply Dark Theme</span>
          </span>
          <span className="home-text711">
            <span>Ola Boluwatife</span>
          </span>
          <span className="home-text713">
            <span>Samsung electronics</span>
          </span>
          <span className="home-text715">
            <span>Search pathology results</span>
          </span>
          <span className="home-text717">
            <span>Chats</span>
          </span>
          <span className="home-text719">
            <span>Settings</span>
          </span>
          <span className="home-text721">
            <span>+234 92 928 2891 +234 60 621 2098</span>
          </span>
          <span className="home-text723">
            <span>Logouts</span>
          </span>
          <span className="home-text725">
            <span>Emergency Hotlines:</span>
          </span>
          <span className="home-text727">
            <span>ACCOUNT</span>
          </span>
          <img
            alt="Shape1238"
            src="/playground_assets/shape1238-h3ha.svg"
            className="home-shape367"
          />
          <div className="home-group74">
            <img
              alt="Shape1240"
              src="/playground_assets/shape1240-je5h.svg"
              className="home-shape368"
            />
            <img
              alt="Shape1241"
              src="/playground_assets/shape1241-fv7d.svg"
              className="home-shape369"
            />
          </div>
          <img
            alt="Shape1242"
            src="/playground_assets/shape1242-eyxq.svg"
            className="home-shape370"
          />
          <img
            alt="Line1243"
            src="/playground_assets/line1243-o3h.svg"
            className="home-line41"
          />
          <img
            alt="Line1244"
            src="/playground_assets/line1244-2kd4.svg"
            className="home-line42"
          />
          <img
            alt="Line1245"
            src="/playground_assets/line1245-3nux.svg"
            className="home-line43"
          />
          <img
            alt="Circle1246"
            src="/playground_assets/circle1246-u5yu-200h.png"
            className="home-circle70"
          />
          <img
            alt="Circle1247"
            src="/playground_assets/circle1247-xkv-200h.png"
            className="home-circle71"
          />
          <img
            alt="Circle1248"
            src="/playground_assets/circle1248-wizf-200h.png"
            className="home-circle72"
          />
          <img
            alt="Shape1249"
            src="/playground_assets/shape1249-q6cc.svg"
            className="home-shape371"
          />
          <img
            alt="Shape1250"
            src="/playground_assets/shape1250-52r5.svg"
            className="home-shape372"
          />
          <img
            alt="Shape1251"
            src="/playground_assets/shape1251-0arn.svg"
            className="home-shape373"
          />
          <img
            alt="Shape1252"
            src="/playground_assets/shape1252-ol2k.svg"
            className="home-shape374"
          />
          <img
            alt="Shape1253"
            src="/playground_assets/shape1253-uzmo.svg"
            className="home-shape375"
          />
          <img
            alt="Shape1254"
            src="/playground_assets/shape1254-9ndl.svg"
            className="home-shape376"
          />
          <img
            alt="Shape1255"
            src="/playground_assets/shape1255-oxj.svg"
            className="home-shape377"
          />
          <img
            alt="Shape1256"
            src="/playground_assets/shape1256-zaro.svg"
            className="home-shape378"
          />
          <img
            alt="Shape1262"
            src="/playground_assets/shape1262-q8wv.svg"
            className="home-shape379"
          />
          <img
            alt="Rectangle1263"
            src="/playground_assets/rectangle1263-p9c.svg"
            className="home-rectangle133"
          />
          <img
            alt="Rectangle1264"
            src="/playground_assets/rectangle1264-783d.svg"
            className="home-rectangle134"
          />
          <img
            alt="Rectangle1265"
            src="/playground_assets/rectangle1265-2jg.svg"
            className="home-rectangle135"
          />
          <img
            alt="Rectangle1266"
            src="/playground_assets/rectangle1266-kocc.svg"
            className="home-rectangle136"
          />
          <span className="home-text729">
            <span>Dr. Ibrahim Yekeni</span>
          </span>
          <span className="home-text731">
            <span>DOC 28 min ago</span>
          </span>
          <span className="home-text733">
            <span>ME 28 min ago</span>
          </span>
          <span className="home-text735">
            <span>
              <span>
                자연어 처리 관련 기업은 회사 A,
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <br></br>
              <span>회사 B, 회사 C 외 5개 회사가 있습니다.</span>
            </span>
          </span>
          <span className="home-text740">
            <span>자연어 처리 관련 기업 찾아줘</span>
          </span>
          <span className="home-text742">
            <span>Start typing here</span>
          </span>
          <span className="home-text744">
            <span>Active 50min ago</span>
          </span>
          <span className="home-text746">1</span>
          <span className="home-text747">2</span>
          <span className="home-text748">1</span>
          <span className="home-text749">
            <span>input text</span>
          </span>
          <span className="home-text751">X</span>
          <img
            alt="KakaoTalkPhoto2022120721342811279"
            src="/playground_assets/kakaotalkphoto2022120721342811279-bgb-200w.png"
            className="home-kakao-talk-photo2022120721342817"
          />
          <span className="home-text752">H</span>
          <span className="home-text753">O</span>
          <span className="home-text754">T</span>
          <span className="home-text755">S</span>
          <span className="home-text756">I</span>
          <span className="home-text757">H</span>
          <span className="home-text758">X</span>
          <img
            alt="Shape1287"
            src="/playground_assets/shape1287-ytxv.svg"
            className="home-shape380"
          />
          <img
            alt="Shape1291"
            src="/playground_assets/shape1291-grqg.svg"
            className="home-shape381"
          />
          <img
            alt="Shape1294"
            src="/playground_assets/shape1294-h59r.svg"
            className="home-shape382"
          />
          <img
            alt="Shape1300"
            src="/playground_assets/shape1300-v08.svg"
            className="home-shape383"
          />
          <img
            alt="Shape1303"
            src="/playground_assets/shape1303-1lr8.svg"
            className="home-shape384"
          />
          <img
            alt="Shape1306"
            src="/playground_assets/shape1306-yu5a.svg"
            className="home-shape385"
          />
          <img
            alt="Shape1310"
            src="/playground_assets/shape1310-zzcb.svg"
            className="home-shape386"
          />
          <img
            alt="Shape1313"
            src="/playground_assets/shape1313-yj6d.svg"
            className="home-shape387"
          />
          <img
            alt="Rectangle1316"
            src="/playground_assets/rectangle1316-36od.svg"
            className="home-rectangle137"
          />
          <img
            alt="Shape1317"
            src="/playground_assets/shape1317-blyg.svg"
            className="home-shape388"
          />
          <span className="home-text759">
            <span>회사 B</span>
          </span>
          <span className="home-text761">
            <span>회사 C</span>
          </span>
        </div>
        <span className="home-text763">
          <span>기술 키워드 : 자연어 처리, 인공지능, 교육, 아동</span>
        </span>
        <span className="home-text765">
          <span>회사 A</span>
        </span>
      </div>
      <div className="home-patient-dashboardlight-theme-login-page3">
        <div className="home-patient-dashboardlight-theme-login-page4">
          <img
            alt="Ellipse119"
            src="/playground_assets/ellipse119-vny.svg"
            className="home-ellipse1"
          />
          <img
            alt="KakaoTalkPhoto202212072134281110"
            src="/playground_assets/kakaotalkphoto202212072134281110-kw3j-200w.png"
            className="home-kakao-talk-photo2022120721342818"
          />
          <span className="home-text767">
            <span>Thank you</span>
          </span>
        </div>
      </div>
    </div>
  )
}

export default Home
